// Dars07 · Amaliyot 10 — Ikki karra qarshi · 🔴 · opposite_double (vau)
// -9 ning qarshisining qarshisi. -9 → 9 → -9 ikki sakrash + salyut.
// jsx-question kontrakti: onReady/registerCheck/onSubmit. O'z tugmasi yo'q.
import React, { useState, useEffect, useRef, useCallback } from 'react';

const IconOk = () => (<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" /></svg>);
const IconNo = () => (<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><line x1="15" y1="9" x2="9" y2="15" /><line x1="9" y1="9" x2="15" y2="15" /></svg>);

const S = {
  wrap: { maxWidth: 640, margin: '0 auto', padding: '4px 2px 8px' },
  eyebrow: { fontSize: 12, fontWeight: 800, letterSpacing: '.04em', color: '#2563eb', textTransform: 'uppercase' },
  setup: { fontSize: 16, lineHeight: 1.5, margin: '6px 0 12px', color: '#374151' },
  ask: { fontSize: 17, fontWeight: 700, margin: '14px 0 12px' },
  mono: { fontFamily: "'JetBrains Mono', ui-monospace, monospace" },
};
const FB = ({ ok, text }) => (
  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10, marginTop: 16, padding: '13px 15px', borderRadius: 14, fontSize: 15, lineHeight: 1.45, fontWeight: 600, background: ok ? '#e8f7ee' : '#fdecec', color: ok ? '#1a7f43' : '#c0392b' }}>
    {ok ? <IconOk /> : <IconNo />}<span>{text}</span>
  </div>
);
const RuleChip = ({ text }) => (
  <div className="d7-pop" style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 10, padding: '10px 13px', borderRadius: 12, fontSize: 13.5, fontWeight: 700, background: '#faf5ff', border: '1.5px solid #e9d5ff', color: '#7c3aed' }}>
    <span style={{ fontSize: 15 }}>💡</span><span>{text}</span>
  </div>
);
function useReg(check, registerCheck) {
  const ref = useRef(check); ref.current = check;
  useEffect(() => { registerCheck?.(() => ref.current()); }, [registerCheck]);
}
function optStyle(picked, i, correctIdx, checked, isReview, opts = {}) {
  const on = picked === i, show = checked && on;
  let bg = '#fff', bd = '#d6dae3', col = '#374151';
  if (on) { bg = '#eaf0fe'; bd = '#2563eb'; col = '#1f2430'; }
  if (show) { const ok = i === correctIdx; bg = ok ? '#e8f7ee' : '#fdecec'; bd = ok ? '#1a7f43' : '#c0392b'; col = ok ? '#1a7f43' : '#c0392b'; }
  return {
    flex: opts.half ? '1 1 45%' : undefined, display: opts.half ? undefined : 'block', width: opts.half ? undefined : '100%',
    textAlign: opts.center ? 'center' : 'left', padding: '13px 14px', borderRadius: 13, border: '2px solid ' + bd,
    background: bg, color: col, fontSize: opts.fs || 16, fontWeight: 700, cursor: (isReview || checked) ? 'default' : 'pointer',
    marginBottom: opts.half ? 0 : 9, fontFamily: opts.mono ? "'JetBrains Mono', monospace" : 'inherit', minHeight: 48,
  };
}

const D10_START = -9, D10_MID = 9, D10_ANS = -9;
const D10_DATA = { correct: 0 };
const D10_T = {
  uz: {
    eyebrow: 'Ikki karra', setup: "Sardor -9 dan boshlab ikki marta qarama-qarshiga o'tdi.",
    ask: '-9 ning qarshisining qarshisi qaysi son?',
    opts: ['-9', '9', '0', '18'],
    correct: "To'g'ri. -9 → 9 (birinchi aks) → -9 (ikkinchi aks). Boshiga qaytdik!",
    wrong: "Maslahat: aksni ikki marta qo'llasangiz, ishora ikki marta almashadi. Ikki almashuvdan keyin qayerga tushasiz?",
    rule: "Qarama-qarshining qarama-qarshisi — har doim dastlabki son.",
  },
  ru: {
    eyebrow: 'Дважды', setup: 'Сардор от -9 дважды перешёл к противоположному.',
    ask: 'Что противоположно противоположному -9?',
    opts: ['-9', '9', '0', '18'],
    correct: 'Верно. -9 → 9 (первое) → -9 (второе). Вернулись к началу!',
    wrong: 'Подсказка: если применить противоположное дважды, знак меняется два раза. Куда попадёшь после двух смен?',
    rule: 'Противоположное к противоположному — всегда исходное число.',
  },
};
export default function D07_10(props) {
  const { lang = 'uz', mode = 'answer', initialAnswer = null, playCorrect, playWrong, onReady, registerCheck, onSubmit } = props || {};
  const t = D10_T[lang] || D10_T.uz;
  const isReview = mode === 'review';
  const [picked, setPicked] = useState(null);
  const [fb, setFb] = useState(null);
  const [checked, setChecked] = useState(false);
  const [ph, setPh] = useState(0); // 1 → 9 · 2 → -9 · 3 salyut
  const timers = useRef([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  useEffect(() => { if (initialAnswer?.studentAnswer?.idx != null) { setPicked(initialAnswer.studentAnswer.idx); if (typeof initialAnswer.correct === 'boolean') { setFb({ correct: initialAnswer.correct }); setChecked(true); if (initialAnswer.correct) setPh(3); } } }, [initialAnswer]);
  useEffect(() => { onReady?.(picked != null && !checked); }, [picked, checked, onReady]);
  const check = useCallback(() => {
    const correct = picked === D10_DATA.correct;
    setFb({ correct }); setChecked(true); correct ? playCorrect?.() : playWrong?.();
    if (correct) [[1, 500], [2, 1500], [3, 2400]].forEach(([v, ms]) => timers.current.push(setTimeout(() => setPh(v), ms)));
    onSubmit?.({ questionText: t.ask, options: t.opts.map((l, i) => ({ id: String(i), label: l })), studentAnswer: { idx: picked, label: t.opts[picked] }, correctAnswer: { idx: 0, label: '-9' }, correct, meta: { tag: 'opposite_double', level: '🔴' } });
  }, [picked, t, playCorrect, playWrong, onSubmit]);
  useReg(check, registerCheck);
  const conf = ['#f59e0b', '#2563eb', '#10b981', '#ec4899', '#7c3aed'];
  const nums = []; for (let v = -11; v <= 11; v++) nums.push(v);
  // token pozitsiyasi: ph 0/boshida -9, ph1 9, ph2+ -9
  const tokenV = ph >= 2 ? -9 : ph >= 1 ? 9 : -9;
  return (
    <div style={S.wrap}>
      <style>{`
        .d7-pop { animation: d7pop .5s cubic-bezier(.34,1.56,.64,1) both; }
        @keyframes d7pop { 0% { opacity: 0; transform: scale(.5); } 100% { opacity: 1; transform: none; } }
        .d7-confetti { animation: d7conf .9s ease-out both; }
        @keyframes d7conf { 0% { opacity: 1; transform: translate(-50%, -50%); } 100% { opacity: 0; transform: translate(calc(-50% + var(--dx)), calc(-50% + var(--dy))); } }
        @media (prefers-reduced-motion: reduce) { .d7-pop, .d7-confetti { animation: none !important; } }
      `}</style>
      <div style={S.eyebrow}>{t.eyebrow}</div>
      <p style={S.setup}>{t.setup}</p>
      <p style={S.ask}>{t.ask}</p>
      {/* aks-ettirish o'qi to'g'ri javobdan keyin */}
      <div style={{ maxHeight: ph >= 1 ? 100 : 0, opacity: ph >= 1 ? 1 : 0, overflow: 'hidden', transition: 'max-height .6s ease, opacity .5s ease', marginBottom: ph >= 1 ? 8 : 0 }}>
        <div style={{ position: 'relative', height: 72, margin: '10px 6px 0' }}>
          <div style={{ position: 'absolute', left: '2%', right: '2%', top: 42, height: 3, background: '#cbd5e1', borderRadius: 2 }} />
          <div style={{ position: 'absolute', left: '50%', top: 28, bottom: 8, width: 2, background: '#94a3b8', transform: 'translateX(-50%)' }} />
          {nums.map((v, i) => {
            const hl = v === -9 || v === 9;
            const c = v === -9 ? '#c0392b' : v === 9 ? '#2563eb' : (v === 0 ? '#64748b' : '#cbd5e1');
            return (
              <div key={v} style={{ position: 'absolute', left: `calc(2% + ${i / (nums.length - 1) * 96}%)`, top: 32, transform: 'translateX(-50%)', textAlign: 'center' }}>
                <div style={{ width: hl ? 13 : 6, height: hl ? 13 : 6, borderRadius: 999, background: hl ? c : '#cbd5e1', margin: '0 auto' }} />
                {(hl || v === 0) && <div style={{ marginTop: 4, fontSize: 11, fontWeight: 800, color: c, ...S.mono }}>{v}</div>}
              </div>
            );
          })}
          <div style={{ position: 'absolute', left: `calc(2% + ${(tokenV + 11) / 22 * 96}%)`, top: 6, transform: 'translateX(-50%)', transition: 'left .8s cubic-bezier(.34,1.56,.64,1)' }}>
            <div style={{ fontSize: 16 }}>⭐</div>
          </div>
        </div>
        <div style={{ textAlign: 'center', minHeight: 24, ...S.mono, fontSize: 18, fontWeight: 800, position: 'relative' }}>
          {ph >= 2 && <span className="d7-pop" style={{ color: '#1a7f43' }}>-9 → 9 → -9</span>}
          {ph >= 3 && Array.from({ length: 12 }).map((_, i) => { const ang = (i / 12) * Math.PI * 2; return <span key={i} className="d7-confetti" style={{ position: 'absolute', left: '50%', top: '50%', width: 7, height: 7, borderRadius: 2, background: conf[i % conf.length], '--dx': Math.cos(ang) * 60 + 'px', '--dy': Math.sin(ang) * 34 + 'px', animationDelay: (i * 0.02) + 's' }} />; })}
        </div>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 9 }}>
        {t.opts.map((o, i) => <button key={i} type="button" style={optStyle(picked, i, 0, checked, isReview, { half: true, center: true, mono: true })} disabled={isReview || checked} onClick={() => setPicked(i)}>{o}</button>)}
      </div>
      {fb && <FB ok={fb.correct} text={fb.correct ? t.correct : t.wrong} />}
      {checked && fb?.correct && t.rule && <RuleChip text={t.rule} />}
    </div>
  );
}
