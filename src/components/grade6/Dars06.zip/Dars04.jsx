import React, { useState, useEffect, useRef, useCallback, createContext, useContext } from 'react';
// УРОК: Умножение десятичных дробей — dec_5_05
// --- ИЗ infrastructure_v1 (строка-в-строку): общая база + секция math (Frac/Op/QuestionScreen/NumInputScreen) ---

// ============================================================
// ПАЛИТРА
// ============================================================
const T = {
  bg: '#F6F4EF',
  ink: '#0E0E10',
  ink2: '#494550',
  ink3: '#8A8883',
  paper: '#FFFFFF',
  accent: '#FF4F28',
  accentSoft: '#FFE8E1',
  success: '#1F7A4D',
  successSoft: '#E3F0E8',
  blue: '#019ACB',
  shadowBase: '58, 53, 48'
};

// ============================================================
// КОНФИГ УРОКА (props от LMS) — модульный, ставится корневым компонентом.
// Движок/SFX/AI читают отсюда; экраны не нужно перепровязывать.
// ============================================================
let ttsConfig = { ttsApiBase: '', correctSoundUrl: '', wrongSoundUrl: '', aiGradingEndpoint: '', studentName: '', voiceGender: 'm' };
const configureLesson = (cfg) => { ttsConfig = { ...ttsConfig, ...cfg }; };

// ============================================================
// TTS-ТЕГИ (язык/тон) — внутри text, в квадратных скобках; на экран НЕ показываются.
// ============================================================
const LANG_TAG = {
  ru: '[Русское произношение]',
  uz: "[O'zbekcha tallaffuz]",
  en: '[English pronunciation]',
};
const END_TAG = '[end]';
const TAG_RE = /\[(Русское произношение|O'zbekcha tallaffuz|English pronunciation|end)\]/g;

const stripAudioTags = (s) => typeof s === 'string'
  ? s.replace(/\[(Русское произношение|O'zbekcha tallaffuz|English pronunciation|end)\]\s*/g, '')
      .replace(/\[[a-zа-яё][^\]]*\]\s*/gi, '')
      .replace(/\s{2,}/g, ' ').trim()
  : s;

// HTTP TTS v5.2: {base}/api/tts?text=<encoded>&g=m|f — ТОЛЬКО text + g.
// Язык — маркерами внутри text (только смешанные строки языковых курсов); math шлёт без маркеров,
// сервер определяет язык сам (ru=кириллица, uz=латиница). Движок свой тег НЕ добавляет.
function buildTtsUrl(base, text, gender) {
  const raw = String(text);
  const enc = encodeURIComponent(raw.slice(0, 1000)).replace(/%5B/g, '[').replace(/%5D/g, ']');
  const g = 'm'; // v5.5-male: erkak ovoz qattiq qulflangan
  return `${base}/api/tts?text=${enc}&g=${g}`;
}

// SFX — короткие звуки верно/неверно, URL из ttsConfig (correctSoundUrl/wrongSoundUrl).
function useSfx() {
  const correctRef = useRef(null);
  const wrongRef = useRef(null);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const { correctSoundUrl, wrongSoundUrl } = ttsConfig;
    if (correctSoundUrl) { const a = new Audio(correctSoundUrl); a.preload = 'auto'; a.volume = 0.6; correctRef.current = a; }
    if (wrongSoundUrl)   { const a = new Audio(wrongSoundUrl);   a.preload = 'auto'; a.volume = 0.6; wrongRef.current = a; }
    return () => {
      try { correctRef.current && correctRef.current.pause(); } catch (e) {}
      try { wrongRef.current && wrongRef.current.pause(); } catch (e) {}
      correctRef.current = null; wrongRef.current = null;
    };
  }, []);
  const play = useCallback((kind) => {
    const ref = kind === 'correct' ? correctRef : wrongRef;
    const a = ref.current; if (!a) { playChime(kind === 'correct'); return; }
    try { a.currentTime = 0; const p = a.play(); if (p && p.catch) p.catch(() => {}); } catch (e) {}
  }, []);
  return { playCorrect: () => play('correct'), playWrong: () => play('wrong') };
}

// Неречевой сигнал (фолбэк SFX в preview / игры закрепления).
let _chimeCtx = null;
function playChime(ok) {
  try {
    if (typeof window === 'undefined') return;
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    _chimeCtx = _chimeCtx || new AC();
    const ctx = _chimeCtx; if (ctx.state === 'suspended') ctx.resume();
    const now = ctx.currentTime;
    const notes = ok ? [660, 880] : [320, 240];
    notes.forEach((f, i) => {
      const o = ctx.createOscillator(); const g = ctx.createGain();
      o.type = 'sine'; o.frequency.value = f;
      const t0 = now + i * 0.12;
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.16, t0 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.18);
      o.connect(g); g.connect(ctx.destination);
      o.start(t0); o.stop(t0 + 0.2);
    });
  } catch (e) { /* no-op */ }
}

// AI-проверка открытых ответов — единственный разрешённый fetch (кроме <audio>.src).
// Возвращает { correct, feedback, transcript? } или бросает.
async function gradeAnswer({ screenIdx, question, rubric, lang, mode, answerText, audioBlob }) {
  const endpoint = ttsConfig.aiGradingEndpoint;
  if (!endpoint) throw new Error('No grading endpoint configured');
  const lessonId = (typeof LESSON_META !== 'undefined' && LESSON_META.lessonId) || '';
  let res;
  if (mode === 'voice') {
    const fd = new FormData();
    fd.append('lessonId', lessonId); fd.append('screenIdx', String(screenIdx));
    fd.append('question', question || ''); fd.append('rubric', rubric || '');
    fd.append('lang', lang); fd.append('mode', 'voice');
    if (audioBlob) fd.append('audio', audioBlob, 'answer.webm');
    res = await fetch(endpoint, { method: 'POST', body: fd });
  } else {
    res = await fetch(endpoint, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ lessonId, screenIdx, question: question || '', rubric: rubric || '', lang, mode: 'text', answerText: answerText || '' }),
    });
  }
  if (!res.ok) throw new Error(`Grading failed: ${res.status}`);
  const data = await res.json();
  if (typeof data.correct !== 'boolean' || typeof data.feedback !== 'string') throw new Error('Malformed grading response');
  return data;
}

// ============================================================
// LANGUAGE CONTEXT + useT
// ============================================================
const LangContext = createContext('ru');
const useLang = () => useContext(LangContext);

const useT = () => {
  const lang = useLang();
  return useCallback((node) => {
    if (node === null || node === undefined) return '';
    if (typeof node === 'string') return stripAudioTags(node);
    if (React.isValidElement(node)) return node;
    if (node[lang] !== undefined) return stripAudioTags(node[lang]);
    return stripAudioTags(node.ru ?? '');
  }, [lang]);
};

// ============================================================
// useIsMobile (design_system 5.0)
// ============================================================
function useIsMobile(breakpoint = 640) {
  const [isMobile, setIsMobile] = useState(
    typeof window !== 'undefined' ? window.innerWidth < breakpoint : false
  );
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const onResize = () => setIsMobile(window.innerWidth < breakpoint);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [breakpoint]);
  return isMobile;
}

// ============================================================
// useMobileZoom — mobil yagona masshtab qatlami (etalon kenglik 390px).
// <640px: butun urok 390px kenglikda joylashadi va real ekranga zoom bilan
// fotografik masshtablanadi — barcha telefonlarda BIR XIL ko'rinish, QA faqat
// 390px da. Desktop (>=640px): --g1z=1, hech narsa o'zgarmaydi.
// Balandlik JS'da o'lchanmaydi: .lesson-root position:fixed + inset:0 —
// brauzer viewport o'zgarishini (URL-panel) o'zi kuzatadi.
// ============================================================
const MOBILE_DESIGN_W = 390;
function useMobileZoom(breakpoint = 640) {
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const root = document.documentElement;
    const apply = () => {
      const z = window.innerWidth < breakpoint ? window.innerWidth / MOBILE_DESIGN_W : 1;
      root.style.setProperty('--g1z', String(z));
    };
    apply();
    window.addEventListener('resize', apply);
    window.addEventListener('orientationchange', apply);
    return () => {
      window.removeEventListener('resize', apply);
      window.removeEventListener('orientationchange', apply);
      root.style.removeProperty('--g1z');
    };
  }, [breakpoint]);
}

// ============================================================
// AUDIO ENGINE
// ============================================================
class AudioEngine {
  constructor() {
    this.queue = [];
    this.currentIdx = 0;
    this.isPlaying = false;
    this.onStateChange = null;
    this.waitingFor = null;
    this.currentLang = 'ru';
    this.gender = 'm';
    this.autoplayBlocked = false;
    this.audioEl = null;
  }

  ensureEl() {
    if (this.audioEl || typeof window === 'undefined') return this.audioEl;
    const el = new Audio();
    el.crossOrigin = 'anonymous';
    el.preload = 'auto';
    this.audioEl = el;
    return el;
  }

  setLang(lang) { this.currentLang = lang; }              // только preview Web Speech
  setGender(g) { this.gender = 'm'; }   // дефолтный пол голоса (v5.2); segment.g переопределяет

  loadQueue(segments) {
    this.stop();
    this.queue = segments || [];
    this.currentIdx = 0;
    this.waitingFor = null;
  }

  playSegment(segment) {
    if (!segment) return;
    const base = ttsConfig.ttsApiBase;
    // Нет текста → пропускаем (логика очереди сохраняется).
    if (!segment.text) {
      this.isPlaying = false;
      if (this.onStateChange) this.onStateChange({ isPlaying: false, currentSegment: null });
      setTimeout(() => this.handleSegmentEnd(segment), 0);
      return;
    }
    // База НЕ пришла от LMS → этап разработки (artifacts). Озвучка через браузерный
    // Web Speech (preview-стендин, «корявый» голос). На платформе эта ветка мёртвая:
    // LMS всегда передаёт ttsApiBase, и тогда идёт HTTP-ветка ниже.
    // speechSynthesis запрещён контрактом в БОЕВОЙ ветке (platform_contract §4);
    // здесь он допустим как preview-стендин — согласовано с разработчиком платформы (июнь 2026).
    if (!base) { this.playSegmentPreview(segment); return; }
    const el = this.ensureEl();
    if (!el) { setTimeout(() => this.handleSegmentEnd(segment), 0); return; }

    el.onended = () => {
      this.isPlaying = false;
      if (this.onStateChange) this.onStateChange({ isPlaying: false, currentSegment: null });
      this.handleSegmentEnd(segment);
    };
    el.onerror = () => {
      this.isPlaying = false;
      if (this.onStateChange) this.onStateChange({ isPlaying: false, currentSegment: null });
      this.handleSegmentEnd(segment);
    };

    const gender = segment.g || this.gender;
    el.src = buildTtsUrl(base, segment.text, gender);
    const p = el.play();
    if (p && typeof p.then === 'function') {
      p.then(() => {
        this.autoplayBlocked = false;
        this.isPlaying = true;
        if (this.onStateChange) this.onStateChange({ isPlaying: true, currentSegment: segment.id });
      }).catch(() => {
        // автоплей заблокирован браузером — ждём первого жеста
        this.autoplayBlocked = true;
        this.isPlaying = false;
        if (this.onStateChange) this.onStateChange({ isPlaying: false, currentSegment: null });
      });
    }
  }

  // PREVIEW-ВЕТКА (только при пустом ttsApiBase, т.е. вне LMS): браузерный Web Speech.
  // НЕ копировать как боевой транспорт — на платформе всегда идёт HTTP-ветка playSegment.
  playSegmentPreview(segment) {
    if (typeof window === 'undefined' || !window.speechSynthesis) {
      setTimeout(() => this.handleSegmentEnd(segment), 0); return;
    }
    const synth = window.speechSynthesis;
    synth.cancel();
    // тег языка/настроения на экран и в Web Speech не нужен — снимаем
    const clean = stripAudioTags(String(segment.text));
    const u = new SpeechSynthesisUtterance(clean);
    const lang = segment.lang || this.currentLang;
    u.lang = lang === 'uz' ? 'uz-UZ' : (lang === 'en' ? 'en-GB' : 'ru-RU');
    u.rate = 0.95; u.pitch = 1.0;
    u.onstart = () => {
      this.isPlaying = true;
      if (this.onStateChange) this.onStateChange({ isPlaying: true, currentSegment: segment.id });
    };
    u.onend = () => {
      this.isPlaying = false;
      if (this.onStateChange) this.onStateChange({ isPlaying: false, currentSegment: null });
      this.handleSegmentEnd(segment);
    };
    u.onerror = () => {
      this.isPlaying = false;
      if (this.onStateChange) this.onStateChange({ isPlaying: false, currentSegment: null });
      this.handleSegmentEnd(segment);
    };
    this.previewUtterance = u;
    setTimeout(() => { try { synth.speak(u); } catch (e) { this.handleSegmentEnd(segment); } }, 60);
  }

  // Возобновление после блокировки автоплея (по первому жесту).
  resumeIfBlocked() {
    if (!this.autoplayBlocked) return;
    this.autoplayBlocked = false;
    this.playSegment(this.queue[this.currentIdx]);
  }

  handleSegmentEnd(segment) {
    if (segment && segment.waits_for) {
      this.waitingFor = segment.waits_for;
      if (this.onStateChange) this.onStateChange({ isPlaying: false, waitingFor: segment.waits_for });
    } else {
      this.currentIdx++;
      this.playNext();
    }
  }

  playNext() {
    if (this.currentIdx >= this.queue.length) return;
    this.playSegment(this.queue[this.currentIdx]);
  }

  start() {
    this.currentIdx = 0;
    this.waitingFor = null;
    this.playNext();
  }

  triggerEvent(eventType, target) {
    if (!this.waitingFor) return;
    const matches = this.waitingFor.type === eventType &&
                   (this.waitingFor.target === target || !this.waitingFor.target);
    if (matches) {
      this.waitingFor = null;
      this.currentIdx++;
      this.playNext();
    }
  }

  triggerInternalEvent(eventName) {
    const nextIdx = this.queue.findIndex((s, i) => i >= this.currentIdx && s.trigger === `on_event:${eventName}`);
    if (nextIdx !== -1) {
      this.currentIdx = nextIdx;
      this.waitingFor = null;
      this.playNext();
    }
  }

  pushOneOff(text, gender) {
    if (!text) return;
    this.queue.push({ id: `oneoff_${Date.now()}`, text, trigger: 'manual', waits_for: null, g: gender });
    this.currentIdx = this.queue.length - 1;
    this.playNext();
  }

  replay() {
    if (this.currentIdx > 0) this.currentIdx--;
    this.waitingFor = null;
    this.playNext();
  }

  stop() {
    if (this.audioEl) {
      try { this.audioEl.pause(); this.audioEl.onended = null; this.audioEl.onerror = null; } catch (e) {}
    }
    // preview-ветка: гасим браузерную озвучку
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      try { window.speechSynthesis.cancel(); } catch (e) {}
    }
    this.isPlaying = false;
    if (this.onStateChange) this.onStateChange({ isPlaying: false, currentSegment: null });
  }
}

let audioEngineInstance = null;
const getAudioEngine = () => {
  if (typeof window === 'undefined') return null;
  if (!audioEngineInstance) audioEngineInstance = new AudioEngine();
  return audioEngineInstance;
};

function useAudio(segments) {
  const lang = useLang();
  const [state, setState] = useState({ isPlaying: false, currentSegment: null, waitingFor: null, muted: false });
  const engineRef = useRef(null);

  // Стабилизация segments по содержимому, не по ссылке (без этого cancel-loop, звук молчит)
  const segmentsRef = useRef(segments);
  const segmentsKey = segments ? JSON.stringify(segments) : '';
  const prevKeyRef = useRef(segmentsKey);
  if (prevKeyRef.current !== segmentsKey) {
    segmentsRef.current = segments;
    prevKeyRef.current = segmentsKey;
  }
  const stableSegments = segmentsRef.current;

  useEffect(() => {
    const engine = getAudioEngine();
    if (!engine) return;
    engineRef.current = engine;
    engine.setLang(lang);
    engine.setGender(ttsConfig.voiceGender || 'm');
    engine.onStateChange = (s) => setState(prev => ({ ...prev, ...s }));
    // Возобновление по первому жесту, если браузер заблокировал автоплей.
    const resume = () => { if (engineRef.current) engineRef.current.resumeIfBlocked(); };
    window.addEventListener('pointerdown', resume);
    window.addEventListener('keydown', resume);
    if (stableSegments && stableSegments.length > 0 && !state.muted) {
      engine.loadQueue(stableSegments);
      const timer = setTimeout(() => engine.start(), 300);
      return () => {
        clearTimeout(timer);
        window.removeEventListener('pointerdown', resume);
        window.removeEventListener('keydown', resume);
        engine.stop();
      };
    }
    return () => {
      window.removeEventListener('pointerdown', resume);
      window.removeEventListener('keydown', resume);
      engine.stop();
    };
  // eslint-disable-next-line
  }, [stableSegments, lang]);

  const triggerEvent = useCallback((type, target) => {
    if (engineRef.current) engineRef.current.triggerEvent(type, target);
  }, []);
  const triggerInternal = useCallback((eventName) => {
    if (engineRef.current) engineRef.current.triggerInternalEvent(eventName);
  }, []);
  const replay = useCallback(() => {
    if (engineRef.current) engineRef.current.replay();
  }, []);
  const toggleMute = useCallback(() => {
    setState(prev => {
      const newMuted = !prev.muted;
      if (newMuted && engineRef.current) engineRef.current.stop();
      return { ...prev, muted: newMuted };
    });
  }, []);

  return { ...state, triggerEvent, triggerInternal, replay, toggleMute };
}

// Хелпер: построить audio-segments для экрана из CONTENT
const makeAudioSegments = (screenContent, lang) => {
  if (Array.isArray(screenContent.audio?.[lang])) {
    return screenContent.audio[lang].map((text, i) => ({
      id: `aud_${i}`,
      text,
      trigger: i === 0 ? 'on_mount' : (i === 1 ? 'after_previous' : `on_event:step_${i - 1}`),
      waits_for: i < screenContent.audio[lang].length - 1
        ? { type: 'button_click', target: 'step' }
        : { type: 'button_click', target: 'next' }
    }));
  }
  const text = screenContent.audio?.[lang];
  if (!text) return [];
  return [{ id: 'aud_0', text, trigger: 'on_mount', waits_for: null }];
};

// ============================================================
// БАЗОВЫЕ КОМПОНЕНТЫ
// ============================================================
const Op = React.memo(({ children, size = 'mid' }) => {
  const fontSize = size === 'big' ? 'clamp(25px, 4.7vw, 38px)' :
                   size === 'mid' ? 'clamp(16px, 3vw, 27px)' :
                   'clamp(12px, 2.1vw, 18px)';
  return <span className="mop" style={{ fontSize }}>{children}</span>;
});

const Frac = React.memo(({ n, d, color, size = 'sm' }) => (
  <span className={`frac frac-${size}`} style={{ color }}>
    <span className="n">{n}</span>
    <span className="bar"/>
    <span className="d">{d}</span>
  </span>
));

// mt: рендерит текст, заменяя «a/b» (и «?/b») настоящей дробью Frac — без слэша.
// Если дробей нет, возвращает строку как есть. Применяется во всех видимых текстах.
const FRAC_RE = /(\d+|\?)\/(\d+)/g;
const mt = (str) => {
  const s = typeof str === 'string' ? str : String(str ?? '');
  if (s.indexOf('/') === -1) return s;
  const out = []; let last = 0; let m; let key = 0;
  FRAC_RE.lastIndex = 0;
  while ((m = FRAC_RE.exec(s)) !== null) {
    if (m.index > last) out.push(s.slice(last, m.index));
    out.push(<Frac key={`mtf${key}`} n={m[1]} d={m[2]} size="sm"/>);
    key += 1;
    last = m.index + m[0].length;
  }
  if (last < s.length) out.push(s.slice(last));
  return out;
};

const AudioIndicator = ({ audioState }) => {
  const { isPlaying, muted, replay, toggleMute } = audioState;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <button onClick={toggleMute} title={muted ? 'Sound on' : 'Sound off'}
        style={{ background: 'transparent', border: 'none', cursor: 'pointer', padding: 4, display: 'flex', alignItems: 'center', color: muted ? T.ink3 : (isPlaying ? T.accent : T.ink2) }}>
        {muted ? (
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
            <line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/>
          </svg>
        ) : isPlaying ? (
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
            <path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>
          </svg>
        ) : (
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
            <path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>
          </svg>
        )}
      </button>
      {!muted && (
        <button onClick={replay} title="Replay"
          style={{ background: 'transparent', border: 'none', cursor: 'pointer', padding: 4, display: 'flex', alignItems: 'center', color: T.ink2 }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/>
          </svg>
        </button>
      )}
    </div>
  );
};

// autoScrollTo — yangi paydo bo'lgan kontentni ko'rinish zonasiga olib keladi.
// 'nearest' — element ko'rinib turgan bo'lsa sakramaydi; reduced-motion'da silliqsiz.
const autoScrollTo = (el, block = 'nearest') => {
  if (!el || typeof el.scrollIntoView !== 'function') return;
  const reduce = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  el.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block });
};

// useRevealScroll — active=true bo'lganda (kontent paydo bo'lganda) unga avtoskroll.
// FeedbackBlock naqshi: double-rAF + kechikish (fade-up animatsiyasi joylashgach).
function useRevealScroll(active, delay = 350, block = 'nearest') {
  const ref = useRef(null);
  useEffect(() => {
    if (!active) return;
    let tid;
    const raf = requestAnimationFrame(() => requestAnimationFrame(() => {
      tid = setTimeout(() => autoScrollTo(ref.current, block), delay);
    }));
    return () => { cancelAnimationFrame(raf); clearTimeout(tid); };
  }, [active, delay, block]);
  return ref;
}

const FeedbackBlock = ({ show, isCorrect, wrongClass, children }) => {
  const [mounted, setMounted] = useState(show);
  const [visible, setVisible] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (show) {
      setMounted(true);
      requestAnimationFrame(() => requestAnimationFrame(() => {
        setVisible(true);
        setTimeout(() => {
          if (ref.current) {
            ref.current.scrollIntoView({ behavior: 'smooth', block: 'end' });
          }
        }, 350);
      }));
    } else {
      setVisible(false);
      const timer = setTimeout(() => setMounted(false), 400);
      return () => clearTimeout(timer);
    }
  }, [show]);
  if (!mounted) return null;
  return (
    <div ref={ref} className={`feedback-block ${visible ? 'visible' : ''}`}>
      <div className={isCorrect ? 'frame-success' : (wrongClass || 'frame-soft')}>{children}</div>
    </div>
  );
};

// Slider — компонент v15 с track-wrap + track-bg + track-fill + glow
const Slider = ({ value, min, max, step = 1, onChange, disabled = false }) => {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="track-wrap">
      <div className="track-bg"/>
      <div className="track-fill" style={{ width: `${pct}%` }}/>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(Number(e.target.value))}
        className="slider-input"
      />
    </div>
  );
};

// Stage — progress + chrome вынесены в отдельный stage-header (sticky, flex-shrink: 0)
const Stage = ({ children, eyebrow, screen, totalScreens, navContent, audioState }) => {
  const t = useT();
  const isMobile = useIsMobile();
  const padH = isMobile ? 12 : 100;
  return (
    <div className="stage">
      <div className="stage-header" style={{ paddingLeft: padH, paddingRight: padH }}>
        <div className="progress-track">
          <div className="progress-bar" style={{ width: `${((screen + 1) / totalScreens) * 100}%` }}/>
        </div>
        <div className="chrome">
          <div className="chrome-left eyebrow">
            <span className="dot"/>
            <span>{t(eyebrow)}</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            {audioState && <AudioIndicator audioState={audioState}/>}
            <div className="mono small" style={{ color: T.ink, fontWeight: 700, fontSize: 14 }}>
              {String(screen + 1).padStart(2, '0')} / {String(totalScreens).padStart(2, '0')}
            </div>
          </div>
        </div>
      </div>
      <div className="stage-content" style={{ paddingLeft: padH, paddingRight: padH }}>
        {children}
      </div>
      {navContent && <div className="stage-nav" style={{ paddingLeft: padH, paddingRight: padH }}>{navContent}</div>}
    </div>
  );
};

const NavBack = ({ onPrev, label = 'Назад' }) => (
  <button className="btn-ghost" onClick={onPrev}
    style={{ padding: 'clamp(10px, 1.7vw, 12px) clamp(15px, 2.1vw, 20px)', fontSize: 'clamp(12px, 1.5vw, 14px)' }}>
    {label}
  </button>
);

const NavNext = ({ disabled, label, onClick }) => (
  <button className="btn-white-accent" disabled={disabled} onClick={onClick}
    style={{ padding: 'clamp(10px, 1.7vw, 12px) clamp(20px, 2.5vw, 27px)', fontSize: 'clamp(12px, 1.5vw, 14px)', marginLeft: 'auto' }}>
    {label}
  </button>
);

const NextLabel = () => {
  const lang = useLang();
  return lang === 'uz' ? 'Davom etish' : 'Дальше';
};

const BackLabel = () => {
  const lang = useLang();
  return lang === 'uz' ? 'Orqaga' : 'Назад';
};

// ============================================================
// QUESTION SCREEN — универсальный MC-компонент под формат audio: { intro, on_correct, on_wrong }
// ============================================================
const QuestionScreen = ({ screen, idx, totalScreens, screenMeta, screenContent, titleNode, question, options, correctIdx, storedAnswer, onAnswer, onNext, onPrev, factOnCorrect, figure }) => {
  const lang = useLang();
  const t = useT();
  const c = screenContent;
  const sfx = useSfx();

  const audio = useAudio([{
    id: `s${idx}_intro`,
    text: c.audio.intro[lang],
    trigger: 'on_mount',
    waits_for: { type: 'option_picked' }
  }]);

  // Веди-до-верного: экран НЕ блокируется на первом ответе.
  // Неверный гаснет и отключается, остальные активны, «Дальше» — только когда выбран верный.
  const wasSolved = storedAnswer?.solved === true || storedAnswer?.correct === true;
  const [solved, setSolved] = useState(wasSolved);
  const [picked, setPicked] = useState(wasSolved ? correctIdx : null);  // текущий показываемый вариант
  const [wrong, setWrong]   = useState(() => new Set());                // погашенные неверные
  const firstTryRef = useRef(storedAnswer ? (storedAnswer.firstTry ?? storedAnswer.correct ?? null) : null);
  const firstIdxRef = useRef(storedAnswer?.studentAnswerIndex ?? null);
  const attemptsRef = useRef(storedAnswer?.attempts ?? (wasSolved ? 1 : 0));
  const introAdvancedRef = useRef(wasSolved);
  // 900ms — FeedbackBlock o'z skrollini (350ms) tugatgandan keyin fakt-kartochkaga o'tamiz.
  const factRef = useRevealScroll(solved && !!factOnCorrect, 900);

  const pick = (i) => {
    if (solved) return;        // после верного — заблокировано
    if (wrong.has(i)) return;  // уже погашенный неверный — игнор
    const isCorrect = i === correctIdx;

    if (firstTryRef.current === null) {   // фиксируем первую попытку (аналитика)
      firstTryRef.current = isCorrect;
      firstIdxRef.current = i;
    }
    attemptsRef.current += 1;
    setPicked(i);

    if (!introAdvancedRef.current) {      // продвинуть intro-очередь один раз
      introAdvancedRef.current = true;
      audio.triggerEvent('option_picked');
    }

    if (isCorrect) {
      setSolved(true);
      sfx.playCorrect();
      onAnswer({
        stage: screenMeta?.scope ?? null,
        screenIdx: idx,
        question: typeof question === 'string' ? question : null,
        options: options.map(o => typeof o === 'string' ? o : null),
        correctIndex: correctIdx,
        correctAnswer: typeof options[correctIdx] === 'string' ? options[correctIdx] : null,
        studentAnswerIndex: firstIdxRef.current,                                   // ПЕРВЫЙ выбор
        studentAnswer: typeof options[firstIdxRef.current] === 'string' ? options[firstIdxRef.current] : null,
        correct: firstTryRef.current,                                              // верность ПЕРВОЙ попытки
        firstTry: firstTryRef.current,
        attempts: attemptsRef.current,
        solved: true
      });
    } else {
      sfx.playWrong();
      setWrong(prev => { const n = new Set(prev); n.add(i); return n; });
    }

    if (!audio.muted) {
      setTimeout(() => {
        const engine = getAudioEngine();
        if (engine && !audio.muted) {
          const wrongVoice = (c[`audio_hint_${i}`] && c[`audio_hint_${i}`][lang]) || (c[`hint_${i}`] && c[`hint_${i}`][lang]) || (c[`wrong_${i}`] && c[`wrong_${i}`][lang]) || c.audio.on_wrong[lang];
          engine.pushOneOff(isCorrect ? c.audio.on_correct[lang] : wrongVoice);
        }
      }, 300);
    }
  };

  const navContent = (
    <>
      <NavBack onPrev={onPrev} label={<BackLabel/>}/>
      <NavNext disabled={!solved} onClick={onNext} label={<NextLabel/>}/>
    </>
  );

  return (
    <Stage eyebrow={c.eyebrow} screen={screen} totalScreens={totalScreens} navContent={navContent} audioState={audio}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 'clamp(16px, 2.6vw, 18px)' }}>
        {titleNode && <Title node={titleNode}/>}
        {/* Заголовок (Title) + текст вопроса остаются и после верного ответа — сворачиваются только неверные варианты. */}
        <div className="fade-up">{question}</div>
        {figure && <div className="frame fade-up delay-1" style={{ display: 'flex', justifyContent: 'center', padding: 'clamp(12px, 2.4vw, 18px)' }}>{figure(solved)}</div>}
        {/* После верного: остаётся только верный вариант, неверные плавно (с задержкой) сворачиваются — keep-visible anti-scroll. */}
        <div className="fade-up delay-1" style={{ display: 'grid', gridTemplateColumns: solved ? '1fr' : 'repeat(2, minmax(0, 1fr))', justifyItems: solved ? 'center' : 'stretch', gap: solved ? 0 : 10 }}>
          {options.map((opt, i) => {
            let cls = 'option';
            const isWrongPicked = wrong.has(i);
            const isCorrect = i === correctIdx;
            const collapse = solved && !isCorrect;        // после верного неверные сворачиваются
            if (solved) {
              if (isCorrect) cls += ' option-correct';
              // неверным НЕ добавляем цвет-класс — плавно гаснут через inline opacity
            } else if (isWrongPicked) {
              cls += ' option-picked-wrong';
            }
            const disabled = solved || isWrongPicked;   // верное решает, погашенный неверный — не кликается; остальные активны
            return (
              <button key={i} className={cls} disabled={disabled} onClick={() => pick(i)}
                style={{ padding: collapse ? '0 clamp(14px, 2.1vw, 19px)' : 'clamp(12px, 1.7vw, 12px) clamp(14px, 2.1vw, 19px)', fontSize: 'clamp(15px, 1.8vw, 16px)', minHeight: collapse ? 0 : 'clamp(50px, 7vw, 60px)', maxHeight: collapse ? 0 : 200, opacity: collapse ? 0 : 1, transform: collapse ? 'translateY(-6px) scale(0.97)' : 'none', width: solved && isCorrect ? '100%' : undefined, maxWidth: solved && isCorrect ? 440 : undefined, borderWidth: collapse ? 0 : undefined, overflow: 'hidden', display: 'flex', alignItems: 'center', gap: 12, transitionProperty: 'opacity, max-height, min-height, padding, transform, margin', transitionDuration: '0.6s, 0.75s, 0.75s, 0.5s, 0.6s, 0.75s', transitionTimingFunction: 'cubic-bezier(0.33, 0, 0.2, 1)', transitionDelay: collapse ? `${i * 0.07}s` : '0s' }}>
                <span className="mono small" style={{ minWidth: 20, color: solved && isCorrect ? T.success : (isWrongPicked ? T.accent : T.ink3) }}>
                  {solved && isCorrect ? '✓' : (isWrongPicked ? '✗' : String.fromCharCode(65 + i))}
                </span>
                <span style={{ flex: 1 }}>{opt}</span>
              </button>
            );
          })}
        </div>
        <FeedbackBlock show={picked !== null} isCorrect={solved} wrongClass="frame-tip">
          <p className="small mono" style={{ margin: 0, marginBottom: 8, fontWeight: 600, color: solved ? T.success : '#D8A93A', textTransform: 'uppercase', letterSpacing: '0.08em', display: 'flex', alignItems: 'center', gap: 6 }}>
            <span aria-hidden="true">{solved ? '✓' : '✗'}</span>{solved ? (lang === 'uz' ? "To'g'ri" : 'Верно') : (lang === 'uz' ? 'Maslahat' : 'Подсказка')}
          </p>
          <p className="body" style={{ margin: 0 }}>
            {mt(solved ? t(c.correct_text) : t(c[`hint_${picked}`] || c[`wrong_${picked}`] || c.wrong_default))}
          </p>
        </FeedbackBlock>
        {solved && factOnCorrect && <div ref={factRef}>{factOnCorrect}</div>}
      </div>
    </Stage>
  );
};


// ============================================================
// --- UROK: div_6_04 — Простые и составные числа / Tub va murakkab sonlar ---
// Infra grade6/Dars01-03 (baytma-bayt). Mobil naqsh BOSHIDAN ichida (ETALON_6SINF.md §5).
// Kontekst: Dars02-03 dagi do'kon dunyosi davomi — narxni necha xil usulda teng
// bo'lish mumkinligi orqali tub/murakkab farqi ochiladi.
// DARSNING O'Q CHIZIG'I: 12 ni ko'p xil bo'lish mumkin, 13 ni esa faqat ikki xil.
// Bo'luvchilar soni hal qiladi: roppa-rosa 2 ta -> tub, 2 tadan ko'p -> murakkab.
// Dars02-03 dagi 2, 3, 5, 9 alomatlari bu yerda TEKSHIRISH QUROLIGA aylanadi.
// s10-s13 da tub ko'paytuvchilarga yoyish qisqacha beriladi — Dars05 (EKUB) uchun tayyorgarlik.
// ============================================================
const TOTAL_SCREENS = 15;
const LESSON_META = {
  lessonId: 'div_6_04',
  lessonTitle: { ru: 'Простые и составные числа', uz: 'Tub va murakkab sonlar' }
};

const SCREEN_META = [
  { id: 's0',  type: 'hook',        template: 'custom',         scored: false, scope: 'hook' },     // 0  (12 va 13, RASM)
  { id: 's1',  type: 'warmup',      template: 'QuestionScreen', scored: false, scope: null },       // 1  (alomatlarni eslash, RASM)
  { id: 's2',  type: 'exploration', template: 'custom',         scored: false, scope: null },       // 2  (bo'luvchilarni sanaymiz)
  { id: 's3',  type: 'rule',        template: 'custom',         scored: false, scope: null },       // 3  (tub / murakkab ta'rifi)
  { id: 's4',  type: 'test',        template: 'QuestionScreen', scored: true,  scope: 'practice' }, // 4  (4 narxdan tubini top, RASM)
  { id: 's5',  type: 'exploration', template: 'custom',         scored: false, scope: null },       // 5  (1 soni alohida + fakt)
  { id: 's6',  type: 'rule',        template: 'custom',         scored: false, scope: null },       // 6  (tekshirish usuli: 2, 3, 5, 7)
  { id: 's7',  type: 'test',        template: 'OddOneOut',      scored: true,  scope: 'practice' }, // 7  (rasmsiz)
  { id: 's8',  type: 'exploration', template: 'custom',         scored: false, scope: null },       // 8  (Eratosfen g'alviri — ko'rsatuv)
  { id: 's9',  type: 'test',        template: 'InputScreen',    scored: true,  scope: 'practice' }, // 9  (20-30 orasida nechta tub, RASM + fakt)
  { id: 's10', type: 'exploration', template: 'custom',         scored: false, scope: null },       // 10 (tub ko'paytuvchilarga yoyish)
  { id: 's11', type: 'test',        template: 'DragMatch',      scored: true,  scope: 'practice' }, // 11 (son -> yoyilma, rasmsiz)
  { id: 's12', type: 'test',        template: 'Classify',       scored: true,  scope: 'practice' }, // 12 (rasmsiz)
  { id: 's13', type: 'test',        template: 'InputScreen',    scored: true,  scope: 'final' },    // 13 (48 ning yoyilmasi, rasmsiz + fakt)
  { id: 's14', type: 'summary',     template: 'custom',         scored: false, scope: null }        // 14
];

const CONTENT = {
  s0: {
    eyebrow: { ru: 'Вопрос урока', uz: 'Dars savoli' },
    global_q: { ru: 'Почему одни числа делятся легко, а другие почти никак?', uz: "Nega ba'zi sonlar oson bo'linadi, ba'zilari esa deyarli hech qanday?" },
    lead: { ru: 'Два ценника рядом: 12 и 13 тысяч. Счёт на 12 тысяч компания разделит хоть на двоих, хоть на троих, хоть на четверых. А счёт на 13 тысяч — только если платит один или скинутся тринадцать человек.', uz: "Yonma-yon ikki narx: 12 va 13 ming. 12 minglik hisobni kompaniya ikki kishiga ham, uch kishiga ham, to'rt kishiga ham bo'la oladi. 13 minglik hisobni esa faqat bitta odam to'laydi yoki o'n uch kishi yig'iladi." },
    question: { ru: 'Как думаешь, чем 13 отличается от 12?', uz: "Nima deb o'ylaysiz, 13 soni 12 dan nimasi bilan farq qiladi?" },
    opt_yes: { ru: 'Кажется, понимаю', uz: "Tushunganga o'xshayman" },
    opt_no: { ru: 'Пока не понимаю', uz: 'Hozircha tushunmadim' },
    opt_idk: { ru: 'Хочу разобраться', uz: "O'rganmoqchiman" },
    audio: {
      intro: { ru: 'Два ценника рядом: двенадцать и тринадцать тысяч. Счёт на двенадцать тысяч компания разделит хоть на двоих, хоть на троих, хоть на четверых. А счёт на тринадцать тысяч только если платит один или скинутся тринадцать человек. Главный вопрос урока: почему одни числа делятся легко, а другие почти никак? Как думаешь, чем тринадцать отличается от двенадцати?', uz: "Yonma-yon ikki narx: o'n ikki va o'n uch ming. O'n ikki minglik hisobni kompaniya ikki kishiga ham, uch kishiga ham, to'rt kishiga ham bo'la oladi. O'n uch minglik hisobni esa faqat bitta odam to'laydi yoki o'n uch kishi yig'iladi. Darsning asosiy savoli: nega ba'zi sonlar oson bo'linadi, ba'zilari esa deyarli hech qanday? Nima deb o'ylaysiz, o'n uch soni o'n ikkidan nimasi bilan farq qiladi?" },
      on_correct: { ru: 'Тогда разберёмся.', uz: 'Unda aniqlab olamiz.' },
      on_wrong: { ru: 'Тогда разберёмся.', uz: 'Unda aniqlab olamiz.' }
    }
  },

  s1: {
    eyebrow: { ru: 'Вспомним', uz: 'Eslaymiz' },
    bridge: { ru: 'Сначала вспомним признаки делимости из прошлых уроков.', uz: "Avval o'tgan darslardagi bo'linish alomatlarini eslaymiz." },
    question: { ru: 'Какую цену смогут разделить поровну и двое, и трое?', uz: "Qaysi narxni ikki kishi ham, uch kishi ham teng bo'la oladi?" },
    opt0: { ru: '8 тысяч', uz: '8 ming' },
    opt1: { ru: '9 тысяч', uz: '9 ming' },
    opt2: { ru: '12 тысяч', uz: '12 ming' },
    opt3: { ru: '10 тысяч', uz: '10 ming' },
    correctIndex: 2,
    correct_text: { ru: 'Верно. 12 — чётное, значит делится на 2. И 1 + 2 = 3, значит делится на 3. Двое платят по 6, трое по 4.', uz: "To'g'ri. 12 — juft, demak 2 ga bo'linadi. Va 1 + 2 = 3, demak 3 ga ham bo'linadi. Ikki kishi 6 mingdan, uch kishi 4 mingdan to'laydi." },
    wrong_0: { ru: '8 чётное, на 2 делится. Но 8 на 3 не делится: 8 = 3 · 2 + 2.', uz: "8 juft, 2 ga bo'linadi. Lekin 8 soni 3 ga bo'linmaydi: 8 = 3 · 2 + 2." },
    wrong_1: { ru: '9 делится на 3, но 9 нечётное — двое поровну не разделят.', uz: "9 soni 3 ga bo'linadi, lekin 9 toq — ikki kishi teng bo'la olmaydi." },
    wrong_3: { ru: '10 чётное, на 2 делится. Но 1 + 0 = 1, на 3 не делится.', uz: "10 juft, 2 ga bo'linadi. Lekin 1 + 0 = 1, 3 ga bo'linmaydi." },
    audio: {
      intro: { ru: 'Сначала разогрев. Какую цену смогут разделить поровну и двое, и трое? Вспомни признаки делимости. Выбери ответ.', uz: "Avval mashq. Qaysi narxni ikki kishi ham, uch kishi ham teng bo'la oladi? Bo'linish alomatlarini eslang. Javobni tanlang." },
      on_correct: { ru: 'Верно. Делится и на два, и на три.', uz: "To'g'ri. Ikkiga ham, uchga ham bo'linadi." },
      on_wrong: { ru: 'Посмотри разбор справа.', uz: "O'ngdagi tushuntirishga qarang." }
    }
  },

  s2: {
    eyebrow: { ru: 'Открытие', uz: 'Kashfiyot' },
    title: { ru: 'Считаем все делители', uz: "Barcha bo'luvchilarni sanaymiz" },
    bridge: { ru: 'Выпишем для каждой цены все числа, на которые её можно разделить поровну.', uz: "Har bir narx uchun uni teng bo'lish mumkin bo'lgan barcha sonlarni yozamiz." },
    audio: {
      ru: [
        'У двенадцати делители один, два, три, четыре, шесть и двенадцать. Целых шесть штук, компания разделит счёт как угодно.',
        'А у тринадцати всего два делителя: один и само тринадцать. Больше ничего не подходит.',
        'У восемнадцати снова шесть делителей. Такие числа делятся легко.',
        'А у девятнадцати опять только два: один и девятнадцать. Вот в чём разница. Всё решает количество делителей.'
      ],
      uz: [
        "O'n ikkining bo'luvchilari: bir, ikki, uch, to'rt, olti va o'n ikki. Butun oltita, kompaniya hisobni xohlagancha bo'la oladi.",
        "O'n uchda esa bor-yo'g'i ikkita bo'luvchi: bir va o'n uchning o'zi. Boshqa hech narsa to'g'ri kelmaydi.",
        "O'n sakkizda yana oltita bo'luvchi. Bunday sonlar oson bo'linadi.",
        "O'n to'qqizda esa yana faqat ikkita: bir va o'n to'qqiz. Farq mana shunda. Hammasini bo'luvchilar soni hal qiladi."
      ]
    }
  },

  s3: {
    eyebrow: { ru: 'Правило', uz: 'Qoida' },
    title: { ru: 'Простые и составные', uz: 'Tub va murakkab' },
    rule_1: { ru: 'Простое число — у него ровно два делителя: 1 и само число. Например, 13 и 19.', uz: "Tub son — uning roppa-rosa ikkita bo'luvchisi bor: 1 va sonning o'zi. Masalan, 13 va 19." },
    rule_2: { ru: 'Составное число — у него больше двух делителей. Например, 12 и 18.', uz: "Murakkab son — uning ikkitadan ko'p bo'luvchisi bor. Masalan, 12 va 18." },
    audio: { ru: 'Запомним правило. Простое число это число, у которого ровно два делителя: единица и само число. Например, тринадцать и девятнадцать. Составное число это число, у которого делителей больше двух. Например, двенадцать и восемнадцать.', uz: "Qoidani eslab qolamiz. Tub son bu shunday sonki, uning roppa-rosa ikkita bo'luvchisi bor: bir va sonning o'zi. Masalan, o'n uch va o'n to'qqiz. Murakkab son bu shunday sonki, uning bo'luvchilari ikkitadan ko'p. Masalan, o'n ikki va o'n sakkiz." }
  },

  s4: {
    eyebrow: { ru: 'Практика', uz: 'Mashq' },
    bridge: { ru: 'Теперь применим определение.', uz: "Endi ta'rifni qo'llaymiz." },
    question: { ru: 'Какая из этих цен — простое число?', uz: 'Bu narxlarning qaysi biri tub son?' },
    opt0: { ru: '21 тысяча', uz: '21 ming' },
    opt1: { ru: '27 тысяч', uz: '27 ming' },
    opt2: { ru: '23 тысячи', uz: '23 ming' },
    opt3: { ru: '33 тысячи', uz: '33 ming' },
    correctIndex: 2,
    correct_text: { ru: 'Верно. 23 не делится ни на 2, ни на 3, ни на 5. Делители только 1 и 23 — это простое число.', uz: "To'g'ri. 23 soni 2 ga ham, 3 ga ham, 5 ga ham bo'linmaydi. Bo'luvchilari faqat 1 va 23 — bu tub son." },
    wrong_0: { ru: '21 = 3 · 7. Кроме 1 и 21 есть ещё делители 3 и 7, значит число составное.', uz: "21 = 3 · 7. 1 va 21 dan tashqari 3 va 7 ham bo'luvchi, demak son murakkab." },
    wrong_1: { ru: '27 = 3 · 9. Сумма цифр 2 + 7 = 9 делится на 3, значит число составное.', uz: "27 = 3 · 9. Raqamlar yig'indisi 2 + 7 = 9, u 3 ga bo'linadi, demak son murakkab." },
    wrong_3: { ru: '33 = 3 · 11. Сумма цифр 3 + 3 = 6 делится на 3, значит число составное.', uz: "33 = 3 · 11. Raqamlar yig'indisi 3 + 3 = 6, u 3 ga bo'linadi, demak son murakkab." },
    audio: {
      intro: { ru: 'Теперь применим определение. Какая из этих цен простое число? Проверь каждую на делимость. Выбери ответ.', uz: "Endi ta'rifni qo'llaymiz. Bu narxlarning qaysi biri tub son? Har birini bo'linishga tekshiring. Javobni tanlang." },
      on_correct: { ru: 'Верно. Только два делителя.', uz: "To'g'ri. Faqat ikkita bo'luvchi." },
      on_wrong: { ru: 'Посмотри разбор справа.', uz: "O'ngdagi tushuntirishga qarang." }
    }
  },

  s5: {
    eyebrow: { ru: 'Открытие', uz: 'Kashfiyot' },
    title: { ru: 'Особый случай — единица', uz: 'Alohida holat — bir soni' },
    bridge: { ru: 'А куда отнести число 1? Посмотрим на его делители.', uz: "1 sonini qayerga qo'yamiz? Uning bo'luvchilariga qaraymiz." },
    fact: { ru: 'Простых чисел бесконечно много — это доказал Евклид больше двух тысяч лет назад. Но чем дальше по числовому ряду, тем реже они встречаются: до 100 их 25, а между 900 и 1000 — только 14.', uz: "Tub sonlar cheksiz ko'p — buni Evklid ikki ming yildan ko'proq vaqt oldin isbotlagan. Lekin son qatorida qanchalik uzoqqa borsak, ular shunchalik kam uchraydi: 100 gacha 25 ta, 900 va 1000 orasida esa atigi 14 ta." },
    fact_audio: { ru: 'Знаешь ли ты? Простых чисел бесконечно много, это доказал Евклид больше двух тысяч лет назад. Но чем дальше по числовому ряду, тем реже они встречаются. До ста их двадцать пять, а между девятьюстами и тысячей только четырнадцать.', uz: "Bilasizmi? Tub sonlar cheksiz ko'p, buni Evklid ikki ming yildan ko'proq vaqt oldin isbotlagan. Lekin son qatorida qanchalik uzoqqa borsak, ular shunchalik kam uchraydi. Yuzgacha ular yigirma beshta, to'qqiz yuz va ming orasida esa atigi o'n to'rtta." },
    audio: {
      ru: [
        'У единицы всего один делитель. Она делится только сама на себя.',
        'Для простого нужно ровно два делителя, а для составного больше двух. Единица не подходит ни туда, ни туда.',
        'Поэтому единицу не относят ни к простым, ни к составным. Она стоит отдельно. Самое маленькое простое число это два.'
      ],
      uz: [
        "Bir sonining bor-yo'g'i bitta bo'luvchisi bor. U faqat o'ziga bo'linadi.",
        "Tub son uchun roppa-rosa ikkita bo'luvchi kerak, murakkab uchun esa ikkitadan ko'p. Bir soni na unisiga, na bunisiga to'g'ri keladi.",
        "Shuning uchun bir soni na tub, na murakkab hisoblanadi. U alohida turadi. Eng kichik tub son bu ikki."
      ]
    }
  },

  s6: {
    eyebrow: { ru: 'Правило', uz: 'Qoida' },
    title: { ru: 'Как проверить число', uz: 'Sonni qanday tekshiramiz' },
    rule_1: { ru: 'Чтобы проверить число до 50, достаточно поделить его на 2, 3, 5 и 7. Признаки делимости уже знакомы.', uz: "50 gacha bo'lgan sonni tekshirish uchun uni 2, 3, 5 va 7 ga bo'lib ko'rish yetarli. Bo'linish alomatlari allaqachon tanish." },
    rule_2: { ru: 'Если ни одно не подошло — число простое. Если хотя бы одно подошло — составное.', uz: "Agar birortasi to'g'ri kelmasa — son tub. Agar hech bo'lmaganda bittasi to'g'ri kelsa — murakkab." },
    audio: { ru: 'Как проверить число. Чтобы проверить число до пятидесяти, достаточно поделить его на два, три, пять и семь. Признаки делимости тебе уже знакомы. Если ни одно не подошло, число простое. Если хотя бы одно подошло, составное.', uz: "Sonni qanday tekshiramiz. Ellikkacha bo'lgan sonni tekshirish uchun uni ikki, uch, besh va yettiga bo'lib ko'rish yetarli. Bo'linish alomatlari sizga allaqachon tanish. Agar birortasi to'g'ri kelmasa, son tub. Agar hech bo'lmaganda bittasi to'g'ri kelsa, murakkab." }
  },

  s7: {
    eyebrow: { ru: 'Практика', uz: 'Mashq' },
    question: { ru: 'Найди число, которое НЕ является простым', uz: 'Tub son BOLMAGAN sonni toping' },
    lead: { ru: 'Картинки нет — проверяй делением на 2, 3, 5 и 7.', uz: "Rasm yo'q — 2, 3, 5 va 7 ga bo'lib tekshiring." },
    items: [
      { num: '11' },
      { num: '13' },
      { num: '17' },
      { num: '21' },
      { num: '29' }
    ],
    errorIdx: 3,
    correct_text: { ru: 'Верно. 21 = 3 · 7, у него четыре делителя: 1, 3, 7 и 21. Остальные числа простые.', uz: "To'g'ri. 21 = 3 · 7, uning to'rtta bo'luvchisi bor: 1, 3, 7 va 21. Qolgan sonlar tub." },
    wrong_0: { ru: '11 не делится ни на 2, ни на 3, ни на 5, ни на 7. Это простое число.', uz: "11 soni 2 ga ham, 3 ga ham, 5 ga ham, 7 ga ham bo'linmaydi. Bu tub son." },
    wrong_1: { ru: '13 тоже простое. Проверь сумму цифр у остальных.', uz: "13 ham tub. Qolganlarining raqamlar yig'indisini tekshiring." },
    wrong_2: { ru: '17 простое. Ищи число, у которого сумма цифр делится на 3.', uz: "17 tub. Raqamlar yig'indisi 3 ga bo'linadigan sonni qidiring." },
    wrong_4: { ru: '29 простое. Осталось одно число, которое выбивается.', uz: "29 tub. Qatorga tushmaydigan bitta son qoldi." },
    audio: {
      intro: { ru: 'Картинки нет, проверяй делением на два, три, пять и семь. Найди число, которое не является простым.', uz: "Rasm yo'q, ikki, uch, besh va yettiga bo'lib tekshiring. Tub son bo'lmagan sonni toping." },
      on_correct: { ru: 'Верно. Двадцать один это три умножить на семь.', uz: "To'g'ri. Yigirma bir bu uch karra yetti." },
      on_wrong: { ru: 'Это простое число. Ищи дальше.', uz: 'Bu tub son. Yana qidiring.' }
    }
  },

  s8: {
    eyebrow: { ru: 'Открытие', uz: 'Kashfiyot' },
    title: { ru: 'Решето Эратосфена', uz: "Eratosfen g'alviri" },
    bridge: { ru: 'Так простые числа искали ещё в Древней Греции: вычёркивают всё лишнее, а что осталось — простое.', uz: "Tub sonlarni Qadimgi Yunonistonda ham shunday qidirishgan: ortiqchasi o'chiriladi, qolgani — tub son." },
    audio: {
      ru: [
        'Выпишем числа от одного до пятидесяти. Единицу сразу вычёркиваем: она не простая и не составная.',
        'Двойку оставляем, а все остальные чётные вычёркиваем. Они делятся на два, значит составные.',
        'Тройку оставляем, её кратные вычёркиваем.',
        'То же делаем с пятёркой и семёркой. Всё, что уцелело, это простые числа. До пятидесяти их пятнадцать.'
      ],
      uz: [
        "Bir dan ellikkacha sonlarni yozamiz. Birni darrov o'chiramiz: u na tub, na murakkab.",
        "Ikkini qoldiramiz, qolgan barcha juft sonlarni o'chiramiz. Ular ikkiga bo'linadi, demak murakkab.",
        "Uchni qoldiramiz, uning karralarini o'chiramiz.",
        "Besh va yetti bilan ham xuddi shunday qilamiz. Omon qolganlarining hammasi tub sonlar. Ellikkacha ular o'n beshta."
      ]
    }
  },

  s9: {
    eyebrow: { ru: 'Практика', uz: 'Mashq' },
    label: { ru: 'ищем простые', uz: 'tublarni qidiramiz' },
    context: { ru: 'В прайсе цены от 20 до 30 тысяч.', uz: "Ro'yxatda narxlar 20 dan 30 minggacha." },
    question: { ru: 'Сколько простых чисел среди чисел от 20 до 30?', uz: '20 dan 30 gacha sonlar orasida nechta tub son bor?' },
    answer: '2',
    placeholder: { ru: 'число', uz: 'son' },
    fb_correct: { ru: 'Верно, всего 2: это 23 и 29. Все остальные делятся на 2, на 3 или на 5.', uz: "To'g'ri, jami 2 ta: bular 23 va 29. Qolganlarining hammasi 2 ga, 3 ga yoki 5 ga bo'linadi." },
    hint: { ru: 'Чётные сразу отбрасывай. Из нечётных проверь 21, 23, 25, 27, 29 на деление 3, 5 и 7.', uz: "Juftlarini darrov chetga suring. Toqlaridan 21, 23, 25, 27, 29 ni 3, 5 va 7 ga bo'lib tekshiring." },
    fact: { ru: 'Простые числа 23 и 29 идут через 6. Такие пары встречаются часто: 11 и 17, 41 и 47. А самые близкие пары отличаются всего на 2 — их называют числами-близнецами.', uz: "23 va 29 tub sonlari orasida 6 farq bor. Bunday juftlar tez-tez uchraydi: 11 va 17, 41 va 47. Eng yaqin juftlar esa atigi 2 ga farq qiladi — ularni egizak sonlar deyishadi." },
    fact_audio: { ru: 'Знаешь ли ты? Простые числа двадцать три и двадцать девять идут через шесть. Такие пары встречаются часто: одиннадцать и семнадцать, сорок один и сорок семь. А самые близкие пары отличаются всего на два, их называют числами-близнецами.', uz: "Bilasizmi? Yigirma uch va yigirma to'qqiz tub sonlari orasida olti farq bor. Bunday juftlar tez-tez uchraydi: o'n bir va o'n yetti, qirq bir va qirq yetti. Eng yaqin juftlar esa atigi ikkiga farq qiladi, ularni egizak sonlar deyishadi." },
    audio: {
      intro: { ru: 'В прайсе цены от двадцати до тридцати тысяч. Сколько простых чисел среди чисел от двадцати до тридцати? Набери ответ.', uz: "Ro'yxatda narxlar yigirmadan o'ttiz minggacha. Yigirmadan o'ttizgacha sonlar orasida nechta tub son bor? Javobni tering." },
      on_correct: { ru: 'Верно, всего два.', uz: "To'g'ri, jami ikkita." },
      on_wrong: { ru: 'Посмотри подсказку.', uz: 'Maslahatga qarang.' }
    }
  },

  s10: {
    eyebrow: { ru: 'Открытие', uz: 'Kashfiyot' },
    title: { ru: 'Составное число из простых', uz: "Murakkab son tublardan yig'iladi" },
    bridge: { ru: 'Любое составное число можно собрать из простых множителей.', uz: "Har qanday murakkab sonni tub ko'paytuvchilardan yig'ish mumkin." },
    audio: {
      ru: [
        'Возьмём двенадцать. Делим на два, получаем шесть. Шесть снова делим на два, получаем три.',
        'Три уже простое, дальше делить нельзя. Значит, двенадцать это два умножить на два умножить на три.',
        'Это удобно записывать столбиком. Слева делимое, справа простой делитель. Двенадцать делим на два, шесть делим на два, три делим на три, и внизу остаётся единица.',
        'Так можно разложить любое составное число. Простые числа здесь как кирпичики, из которых собраны все остальные. Это пригодится нам на следующем уроке.'
      ],
      uz: [
        "O'n ikkini olamiz. Ikkiga bo'lamiz, olti chiqadi. Oltini yana ikkiga bo'lamiz, uch chiqadi.",
        "Uch allaqachon tub, uni boshqa bo'lib bo'lmaydi. Demak, o'n ikki bu ikki karra ikki karra uch.",
        "Buni ustun shaklida yozish qulay. Chapda bo'linuvchi, o'ngda tub bo'luvchi. O'n ikkini ikkiga, oltini ikkiga, uchni uchga bo'lamiz, pastda bir qoladi.",
        "Shu tarzda har qanday murakkab sonni yoyish mumkin. Tub sonlar bu yerda g'ishtga o'xshaydi, qolgan hamma son ulardan yig'ilgan. Bu bizga keyingi darsda asqotadi."
      ]
    }
  },

  s11: {
    eyebrow: { ru: 'Практика', uz: 'Mashq' },
    title: { ru: 'Собери число из простых', uz: "Sonni tublardan yig'ing" },
    lead: { ru: 'Для каждого числа выбери верное разложение. Картинки нет.', uz: "Har bir son uchun to'g'ri yoyilmani tanlang. Rasm yo'q." },
    pairs: [
      { number: '18', label: { ru: 'тысяч', uz: 'ming' }, reading: { ru: '2 · 3 · 3', uz: '2 · 3 · 3' } },
      { number: '20', label: { ru: 'тысяч', uz: 'ming' }, reading: { ru: '2 · 2 · 5', uz: '2 · 2 · 5' } },
      { number: '30', label: { ru: 'тысяч', uz: 'ming' }, reading: { ru: '2 · 3 · 5', uz: '2 · 3 · 5' } }
    ],
    correct_text: { ru: 'Верно. Проверить легко: перемножь множители обратно и должно получиться исходное число.', uz: "To'g'ri. Tekshirish oson: ko'paytuvchilarni teskari ko'paytiring va dastlabki son chiqishi kerak." },
    hint: { ru: 'Дели число на самое маленькое простое, которое подходит, и продолжай, пока не останется простое.', uz: "Sonni unga to'g'ri keladigan eng kichik tub songa bo'ling va tub son qolguncha davom eting." },
    audio: {
      intro: { ru: 'Картинки нет. Для каждого числа выбери верное разложение. Нажми на число, потом выбери строку из списка.', uz: "Rasm yo'q. Har bir son uchun to'g'ri yoyilmani tanlang. Songa bosing, so'ng ro'yxatdan qatorni tanlang." },
      on_correct: { ru: 'Верно, все разложения на местах.', uz: "To'g'ri, barcha yoyilmalar o'z o'rniga tushdi." },
      on_wrong: { ru: 'Проверь ещё раз.', uz: 'Yana bir bor tekshiring.' }
    }
  },

  s12: {
    eyebrow: { ru: 'Практика', uz: 'Mashq' },
    title: { ru: 'Простое или составное?', uz: 'Tubmi yoki murakkabmi?' },
    lead: { ru: 'Разбери числа на две группы. Картинки нет — проверяй делением.', uz: "Sonlarni ikki guruhga ajrating. Rasm yo'q — bo'lib tekshiring." },
    bin_a: { ru: 'Простое', uz: 'Tub' },
    bin_b: { ru: 'Составное', uz: 'Murakkab' },
    cards: [
      { label: '19', bin: 'a' },
      { label: '21', bin: 'b' },
      { label: '23', bin: 'a' },
      { label: '27', bin: 'b' },
      { label: '31', bin: 'a' },
      { label: '33', bin: 'b' }
    ],
    hint: { ru: 'Проверь по очереди: делится ли на 2, на 3, на 5, на 7. Если нет — число простое.', uz: "Navbat bilan tekshiring: 2 ga, 3 ga, 5 ga, 7 ga bo'linadimi. Agar yo'q bo'lsa — son tub." },
    correct_text: { ru: 'Точно. 19, 23 и 31 не делятся ни на что, кроме 1 и себя. А 21 = 3 · 7, 27 = 3 · 9, 33 = 3 · 11.', uz: "Aniq. 19, 23 va 31 sonlari 1 va o'zidan boshqa hech narsaga bo'linmaydi. 21 = 3 · 7, 27 = 3 · 9, 33 = 3 · 11." },
    audio: {
      intro: { ru: 'Разбери числа на две группы. Простое или составное? Проверяй делением.', uz: "Sonlarni ikki guruhga ajrating. Tubmi yoki murakkabmi? Bo'lib tekshiring." },
      on_correct: { ru: 'Точно, все на местах.', uz: "Aniq, hammasi o'z o'rniga tushdi." },
      on_wrong: { ru: 'Не сюда.', uz: 'Bu yerga emas.' }
    }
  },

  s13: {
    eyebrow: { ru: 'Итог урока', uz: 'Dars yakuni' },
    label: { ru: 'финальная задача', uz: 'yakuniy masala' },
    context: { ru: 'Разложи число 48 на простые множители. Картинки нет.', uz: "48 sonini tub ko'paytuvchilarga yoying. Rasm yo'q." },
    question: { ru: 'Сколько простых множителей получится у числа 48?', uz: "48 sonida nechta tub ko'paytuvchi chiqadi?" },
    answer: '5',
    placeholder: { ru: 'число', uz: 'son' },
    fb_correct: { ru: 'Верно, 5 множителей: 48 = 2 · 2 · 2 · 2 · 3. Четыре двойки и одна тройка.', uz: "To'g'ri, 5 ta ko'paytuvchi: 48 = 2 · 2 · 2 · 2 · 3. To'rtta ikki va bitta uch." },
    hint: { ru: 'Дели на 2, пока делится: 48, 24, 12, 6, 3. Сколько раз поделил и что осталось в конце?', uz: "Bo'linguncha 2 ga bo'lavering: 48, 24, 12, 6, 3. Necha marta bo'ldingiz va oxirida nima qoldi?" },
    fact: { ru: 'Разложение на простые множители у каждого числа единственное — в каком порядке ни дели, набор множителей получится тот же. Это правило называют основной теоремой арифметики.', uz: "Har bir sonning tub ko'paytuvchilarga yoyilmasi yagona — qanday tartibda bo'lmang, ko'paytuvchilar to'plami bir xil chiqadi. Bu qoidani arifmetikaning asosiy teoremasi deyishadi." },
    fact_audio: { ru: 'Знаешь ли ты? Разложение на простые множители у каждого числа единственное. В каком порядке ни дели, набор множителей получится тот же. Это правило называют основной теоремой арифметики.', uz: "Bilasizmi? Har bir sonning tub ko'paytuvchilarga yoyilmasi yagona. Qanday tartibda bo'lmang, ko'paytuvchilar to'plami bir xil chiqadi. Bu qoidani arifmetikaning asosiy teoremasi deyishadi." },
    audio: {
      intro: { ru: 'Финальная задача. Разложи число сорок восемь на простые множители. Сколько простых множителей получится? Набери ответ.', uz: "Yakuniy masala. Qirq sakkiz sonini tub ko'paytuvchilarga yoying. Nechta tub ko'paytuvchi chiqadi? Javobni tering." },
      on_correct: { ru: 'Верно, пять множителей.', uz: "To'g'ri, besh ta ko'paytuvchi." },
      on_wrong: { ru: 'Посмотри подсказку.', uz: 'Maslahatga qarang.' }
    }
  },

  s14: {
    eyebrow: { ru: 'Урок пройден', uz: "Dars o'tildi" },
    heading: { ru: 'Простые и составные числа', uz: 'Tub va murakkab sonlar' },
    score_label: { ru: 'заданий выполнено с первой попытки', uz: 'topshiriq birinchi urinishda bajarildi' },
    main_label: { ru: 'Главное', uz: 'Asosiysi' },
    main_1: { ru: 'У простого числа ровно два делителя: 1 и оно само. У составного — больше двух.', uz: "Tub sonning roppa-rosa ikkita bo'luvchisi bor: 1 va sonning o'zi. Murakkabniki esa ikkitadan ko'p." },
    main_2: { ru: 'Число 1 не простое и не составное — у него всего один делитель. Самое маленькое простое число — 2.', uz: "1 soni na tub, na murakkab — uning bor-yo'g'i bitta bo'luvchisi bor. Eng kichik tub son — 2." },
    main_3: { ru: 'Любое составное число раскладывается на простые множители: 12 = 2 · 2 · 3.', uz: "Har qanday murakkab son tub ko'paytuvchilarga yoyiladi: 12 = 2 · 2 · 3." },
    hook_close: { ru: 'Теперь ясно, чем 13 отличается от 12: у 12 шесть делителей, а у 13 всего два. Поэтому счёт на 12 тысяч делится легко, а на 13 — почти никак.', uz: "Endi aniq, 13 soni 12 dan nimasi bilan farq qilishi: 12 da oltita bo'luvchi bor, 13 da esa bor-yo'g'i ikkita. Shuning uchun 12 minglik hisob oson bo'linadi, 13 minglik esa deyarli hech qanday." },
    conn_label_refs: { ru: 'Опирается на', uz: 'Nimaga tayanadi' },
    conn_refs: { ru: 'признаки делимости на 2, 3, 5 и 9', uz: "2, 3, 5 va 9 ga bo'linish alomatlari" },
    conn_label_next: { ru: 'Дальше', uz: 'Keyingi' },
    conn_next: { ru: 'наибольший общий делитель (НОД)', uz: "eng katta umumiy bo'luvchi (EKUB)" },
    audio: {
      ru: [
        'Урок пройден. Соберём главное.',
        'У простого числа ровно два делителя: единица и оно само. У составного делителей больше двух. А единица не простая и не составная, у неё всего один делитель.',
        'Любое составное число раскладывается на простые множители. Простые числа это кирпичики, из которых собраны все остальные. Дальше разберём наибольший общий делитель.'
      ],
      uz: [
        "Dars o'tildi. Asosiysini yig'amiz.",
        "Tub sonning roppa-rosa ikkita bo'luvchisi bor: bir va sonning o'zi. Murakkab sonda bo'luvchilar ikkitadan ko'p. Bir soni esa na tub, na murakkab, uning bor-yo'g'i bitta bo'luvchisi bor.",
        "Har qanday murakkab son tub ko'paytuvchilarga yoyiladi. Tub sonlar bu g'ishtga o'xshaydi, qolgan hamma son ulardan yig'ilgan. Keyin eng katta umumiy bo'luvchini ko'rib chiqamiz."
      ]
    }
  }
};

// ============================================================
// SHUFFLE / FORMAT / ANIM HELPERS (div_6_04)
// ============================================================
const shuffleMC = (c, options, correctIdx, order) => {
  const content = { ...c };
  order.forEach((oldI, newI) => { content[`wrong_${newI}`] = c[`wrong_${oldI}`]; content[`hint_${newI}`] = c[`hint_${oldI}`]; });
  return { options: order.map(i => options[i]), correctIdx: order.indexOf(correctIdx), content };
};
const fmtNum = (n) => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
const shuffleArr = (a) => { const r = [...a]; for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; };

function useCountUp(target, duration = 1100) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    let raf, start = null;
    const tick = (ts) => {
      if (start === null) start = ts;
      const p = Math.min((ts - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(Math.floor(eased * target));
      if (p < 1) raf = requestAnimationFrame(tick); else setVal(target);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return val;
}
const CountUp = ({ target, duration, style, className }) => {
  const v = useCountUp(target, duration);
  return <span className={className} style={style}>{fmtNum(v)}</span>;
};

// ============================================================
// ============================================================
// ============================================================
// ============================================================
// BO'LUVCHILAR SONI — darsning asosiy vizual modeli.
// Dars01 da "nechta xil usulda teng joylash mumkin" savoli qo'yilgan edi; bu yerda
// o'sha savol hukm chiqaradi: roppa-rosa 2 ta bo'luvchi -> tub, ko'proq -> murakkab.
// Markaziy komponent — DivisorFan.
// ============================================================
const CoinIcon = ({ s = 18 }) => (
  <svg width={s} height={s} viewBox="0 0 24 24" aria-hidden="true" style={{ display: 'block', flexShrink: 0 }}>
    <circle cx="12" cy="12" r="10" fill="#C9922B"/>
    <circle cx="12" cy="12" r="8" fill="#F6C453"/>
    <circle cx="12" cy="12" r="8" fill="none" stroke="#C9922B" strokeWidth="0.9" opacity="0.6"/>
  </svg>
);

// Narx yorlig'i: son + birlik. Do'kondagi narx shaklida.
const PriceTag = ({ value, unit, tone = 'plain', size = 'md' }) => {
  const bg = tone === 'ok' ? '#E3F0E8' : (tone === 'no' ? '#FFE8E1' : '#FFFFFF');
  const fg = tone === 'ok' ? T.success : (tone === 'no' ? T.accent : T.ink);
  const bd = tone === 'ok' ? T.success : (tone === 'no' ? T.accent : 'rgba(167, 166, 162, 0.4)');
  const fs = size === 'lg' ? 'clamp(22px, 5vw, 34px)' : 'clamp(15px, 3vw, 21px)';
  return (
    <span className="pr-tag" style={{ background: bg, borderColor: bd, color: fg }}>
      <span className="mono" style={{ fontSize: fs, fontWeight: 700, lineHeight: 1 }}>{value}</span>
      {unit && <span className="mono" style={{ fontSize: 'clamp(9px, 1.9vw, 11px)', opacity: 0.75 }}>{unit}</span>}
    </span>
  );
};

const divisorsOf = (n) => { const r = []; for (let i = 1; i <= n; i++) { if (n % i === 0) r.push(i); } return r; };

// Darsning yuragi: sonning barcha bo'luvchilari chip bo'lib yoyiladi va sanaladi.
// Tub sonda ikkita chip qoladi — bu ko'zga darrov tashlanadi.
const DivisorFan = ({ value, tone = 'plain', countLabel, size = 'md' }) => {
  const ds = divisorsOf(value);
  const col = tone === 'ok' ? T.success : (tone === 'no' ? T.accent : T.ink2);
  const bg = tone === 'ok' ? '#E3F0E8' : (tone === 'no' ? '#FFE8E1' : '#F1EFE9');
  const fs = size === 'lg' ? 'clamp(15px, 3vw, 20px)' : 'clamp(13px, 2.5vw, 17px)';
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 'clamp(4px, 1.1vw, 8px)' }}>
        {ds.map((d, i) => (
          <span key={d} className="df-chip mono" style={{ fontSize: fs, animationDelay: `${i * 0.06}s` }}>{d}</span>
        ))}
      </div>
      <span className="df-count mono" style={{ color: col, background: bg, borderColor: col }}>
        {ds.length}{countLabel ? ` ${countLabel}` : ''}
      </span>
    </div>
  );
};

// Eratosfen g'alviri — KO'RSATUV (bola bosmaydi, qadamlar avtomatik o'chiradi).
// step 0: 1 o'chadi · 1: 2 ning karralari · 2: 3 ning karralari · 3: 5 va 7 niki.
// 50 gacha 2, 3, 5, 7 ni tekshirish yetarli, chunki 7 * 7 = 49.
const SIEVE_PRIMES = [[], [2], [2, 3], [2, 3, 5, 7]];
const sieveState = (n, step) => {
  if (n === 1) return 'crossed';
  const ps = SIEVE_PRIMES[Math.min(step, SIEVE_PRIMES.length - 1)];
  for (const p of ps) { if (n !== p && n % p === 0) return 'crossed'; }
  return step >= 3 ? 'prime' : 'plain';
};
const SieveGrid = ({ max = 50, step = 0 }) => (
  <div className="sv-grid">
    {Array.from({ length: max }).map((_, i) => {
      const n = i + 1;
      const st = sieveState(n, step);
      return <span key={n} className={`sv-cell mono sv-${st}`}>{n}</span>;
    })}
  </div>
);

// Tub ko'paytuvchilarga yoyish: 12 = 2 * 2 * 3 (Dars05 uchun tayyorgarlik).
const primeFactors = (n) => { const r = []; let x = n; for (let p = 2; p * p <= x; p++) { while (x % p === 0) { r.push(p); x /= p; } } if (x > 1) r.push(x); return r; };
const FactorChain = ({ value, showValue = true }) => {
  const fs = primeFactors(value);
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'center', gap: 'clamp(4px, 1.1vw, 8px)' }}>
      {showValue && (
        <>
          <span className="mono" style={{ fontSize: 'clamp(17px, 3.4vw, 24px)', fontWeight: 700, color: T.ink }}>{value}</span>
          <span className="mono" style={{ fontSize: 'clamp(15px, 3vw, 20px)', color: T.ink3 }}>=</span>
        </>
      )}
      {fs.map((f, i) => (
        <React.Fragment key={i}>
          {i > 0 && <span className="mono" style={{ fontSize: 'clamp(13px, 2.6vw, 17px)', color: T.ink3 }}>·</span>}
          <span className="fc-chip mono" style={{ animationDelay: `${i * 0.09}s` }}>{f}</span>
        </React.Fragment>
      ))}
    </div>
  );
};

// Ustun (столбик) usuli: sonni tublarga ketma-ket bo'lamiz — chapda bo'linuvchi,
// o'ngda tub bo'luvchi, pastda 1 qolguncha. Qatorlar ketma-ket paydo bo'ladi (animatsiya).
const FactorLadder = ({ value }) => {
  const rows = [];
  let x = value, p = 2;
  while (x > 1) { if (x % p === 0) { rows.push([x, p]); x = x / p; } else { p = p === 2 ? 3 : p + 2; } }
  return (
    <div className="ladder" aria-hidden="true">
      {rows.map(([n, d], i) => (
        <div className="ladder-row" key={i} style={{ animationDelay: `${i * 0.16}s` }}>
          <span className="ladder-n mono">{n}</span>
          <span className="ladder-bar"/>
          <span className="ladder-p mono">{d}</span>
        </div>
      ))}
      <div className="ladder-row" style={{ animationDelay: `${rows.length * 0.16}s` }}>
        <span className="ladder-n ladder-one mono">1</span>
        <span className="ladder-bar"/>
        <span className="ladder-p mono"/>
      </div>
    </div>
  );
};

// Alomat / ta'rif chiplari (qoida ekranlarida).
const DivisorChips = ({ list, active = -1 }) => (
  <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 'clamp(6px, 1.4vw, 10px)' }}>
    {list.map((d, i) => (
      <span key={i} className="dv-chip" style={{ animationDelay: `${i * 0.07}s`, background: active === i ? T.accentSoft : '#FFFFFF', color: active === i ? T.accent : T.ink, borderColor: active === i ? T.accent : 'rgba(167, 166, 162, 0.35)' }}>{d}</span>
    ))}
  </div>
);
// Xona katakchalari: bir sinf ichidagi uch raqam to'lganda yashilga o'tadi.
const PlaceGrid = ({ answer, filled }) => {
  const digits = String(answer).split('');
  const n = digits.length;
  return (
    <div style={{ display: 'flex', justifyContent: 'center', gap: 6, flexWrap: 'wrap' }}>
      {digits.map((d, i) => {
        const classBreak = (n - i) % 3 === 0 && i !== 0;
        return (
          <React.Fragment key={i}>
            {classBreak && <span style={{ width: 8 }}/>}
            <span className={`place-cell ${filled ? 'filled' : ''}`} style={{ transitionDelay: `${i * 0.05}s` }}>{filled ? d : '·'}</span>
          </React.Fragment>
        );
      })}
    </div>
  );
};

// ============================================================
// FACTCARD — ovozli fakt to'g'ri javobdan keyin (ko'k tema + darsga xos Anim*).
// ============================================================
const FB_IT   = { ru: 'Знаешь ли ты? · IT',    uz: "Bilasizmi? · IT" };
const FB_SCI  = { ru: 'Знаешь ли ты? · Наука', uz: "Bilasizmi? · Fan" };
const FB_HIST = { ru: 'Знаешь ли ты? · История', uz: "Bilasizmi? · Tarix" };
const FactCard = ({ text, anim, badge }) => {
  const t = useT();
  return (
    <div className="fact-card fade-up">
      <div className="fact-anim">{anim}</div>
      <div className="fact-body">
        <p className="fact-badge"><span className="fact-dot"/>{t(badge)}</p>
        <p className="fact-text">{mt(t(text))}</p>
      </div>
    </div>
  );
};
const AnimDigits = () => (<div className="fa-dg" aria-hidden="true">{Array.from({ length: 3 }).map((_, g) => (<span key={g} className="fa-dg-grp">{Array.from({ length: 3 }).map((_, d) => (<i key={d}/>))}</span>))}</div>);
const AnimStars = () => (<div className="fa-st" aria-hidden="true">{Array.from({ length: 9 }).map((_, i) => (<span key={i} style={{ animationDelay: `${i * 0.22}s` }}/>))}</div>);
const AnimData = () => (<div className="fa-da" aria-hidden="true">{[40, 60, 80, 100].map((h, i) => (<span key={i} style={{ height: `${h}%`, animationDelay: `${i * 0.2}s` }}/>))}</div>);

// ============================================================
// SHARED SCREEN HELPERS
// ============================================================
const Title = ({ node }) => { const t = useT(); return <h2 className="title h-title fade-up" style={{ margin: 0 }}>{mt(t(node))}</h2>; };
const Floaters = () => (<div className="amb" aria-hidden="true"><span className="amb-o amb-o1"/><span className="amb-o amb-o2"/><span className="amb-o amb-o3"/></div>);
const StepLine = ({ children, soft }) => (
  <div className={`fade-up ${soft ? 'frame-tip' : 'frame'}`} style={{ padding: 'clamp(12px, 2vw, 16px)' }}>
    <p className="body" style={{ margin: 0, color: T.ink }}>{children}</p>
  </div>
);
// Bosqichli izohlar yig'iladi: oldingi qatorlar (so'lg'in) qoladi, yangisi pastdan chiqadi (fade-up).
const StepLinesAccum = ({ lines, step }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 'clamp(8px, 1.5vw, 12px)' }}>
    {lines.slice(0, step + 1).map((ln, i) => {
      const isCurrent = i === step;
      return (
        <div key={i} className={`${isCurrent ? 'fade-up frame' : 'frame-tip'}`} style={{ padding: 'clamp(12px, 2vw, 16px)', opacity: isCurrent ? 1 : 0.72, transition: 'opacity 0.4s ease' }}>
          <p className="body" style={{ margin: 0, color: isCurrent ? T.ink : T.ink2 }}>{ln}</p>
        </div>
      );
    })}
  </div>
);
const HintBlock = ({ show, children }) => {
  const lang = useLang();
  if (!show) return null;
  return (
    <div className="frame-tip fade-up" style={{ padding: 'clamp(12px, 2vw, 16px)' }}>
      <p className="small mono" style={{ margin: 0, marginBottom: 6, fontWeight: 600, color: '#D8A93A', textTransform: 'uppercase', letterSpacing: '0.08em', display: 'flex', alignItems: 'center', gap: 6 }}><span aria-hidden="true">✗</span>{lang === 'uz' ? 'Maslahat' : 'Подсказка'}</p>
      <p className="body" style={{ margin: 0, color: T.ink }}>{children}</p>
    </div>
  );
};
const ConnectionsBlock = ({ c }) => {
  const t = useT();
  return (
    <div className="frame-tip fade-up delay-3" style={{ position: 'relative', display: 'flex', flexDirection: 'column', gap: 8 }}>
      <p className="small" style={{ margin: 0 }}><span style={{ fontWeight: 700, color: T.ink }}>🔗 {t(c.conn_label_refs)}:</span> {t(c.conn_refs)}</p>
      <p className="small" style={{ margin: 0 }}><span style={{ fontWeight: 700, color: T.accent }}>➡️ {t(c.conn_label_next)}:</span> {t(c.conn_next)}</p>
    </div>
  );
};

// Bosqichli kashfiyot: bitta ovozli qator + bitta ko'rinadigan izoh (skrollsiz, qatorlar yig'ilmaydi).
const StepExploration = ({ screen, screenContent, onNext, onPrev, totalScreens, renderBody, factOnLast }) => {
  const c = screenContent;
  const t = useT();
  const lang = useLang();
  const lines = c.audio[lang];
  const last = lines.length - 1;
  const audio = useAudio([{ id: `s${screen}_a0`, text: lines[0], trigger: 'on_mount', waits_for: null }]);
  const [step, setStep] = useState(0);
  const factVoicedRef = useRef(false);
  const speak = (txt) => { if (!audio.muted) { const e = getAudioEngine(); if (e) e.pushOneOff(txt); } };
  const handleStep = () => {
    if (step < last) { const ns = step + 1; setStep(ns); speak(lines[ns]); if (ns === last && factOnLast && c.fact_audio && !factVoicedRef.current) { factVoicedRef.current = true; speak(c.fact_audio[lang]); } }
    else { onNext(); }
  };
  // Bitta qatorli kashfiyotda ham faktni oxirida ovozlash.
  useEffect(() => { if (last === 0 && factOnLast && c.fact_audio && !factVoicedRef.current) { factVoicedRef.current = true; if (!audio.muted) { const e = getAudioEngine(); if (e) e.pushOneOff(c.fact_audio[lang]); } } /* eslint-disable-next-line */ }, []);
  const navContent = (<><NavBack onPrev={onPrev} label={<BackLabel/>}/><NavNext label={<NextLabel/>} onClick={handleStep}/></>);
  return (<Stage eyebrow={c.eyebrow} screen={screen} totalScreens={totalScreens} navContent={navContent} audioState={audio}>{renderBody({ t, lang, step, last })}</Stage>);
};

// Qoida ekrani (s3, s6): ikki qoida qatori (pale-yellow) + misol.
const RuleScreen = ({ screen, screenContent, onNext, onPrev, totalScreens, exampleNode }) => {
  const c = screenContent;
  const t = useT();
  const lang = useLang();
  const audio = useAudio([{ id: `s${screen}_a`, text: c.audio[lang], trigger: 'on_mount', waits_for: null }]);
  const navContent = (<><NavBack onPrev={onPrev} label={<BackLabel/>}/><NavNext onClick={onNext} label={<NextLabel/>}/></>);
  return (
    <Stage eyebrow={c.eyebrow} screen={screen} totalScreens={totalScreens} navContent={navContent} audioState={audio}>
      <div style={{ position: 'relative', flex: 1, display: 'flex', flexDirection: 'column', gap: 'clamp(14px, 2.3vw, 20px)', justifyContent: 'center' }}>
        <Floaters/>
        <h2 className="title h-title fade-up" style={{ position: 'relative', margin: 0 }}>{t(c.title)}</h2>
        <div className="frame-tip fade-up delay-1" style={{ position: 'relative' }}><p className="body" style={{ margin: 0, color: T.ink }}>{t(c.rule_1)}</p></div>
        <div className="frame-tip fade-up delay-2" style={{ position: 'relative' }}><p className="body" style={{ margin: 0, color: T.ink }}>{t(c.rule_2)}</p></div>
        <div className="frame fade-up delay-3" style={{ position: 'relative', textAlign: 'center' }}>
          {exampleNode || <p className="body" style={{ margin: 0, color: T.ink }}>{t(c.example)}</p>}
        </div>
      </div>
    </Stage>
  );
};

// Javob terish ekrani (s9, s13) — keep-visible: savol qoladi, faqat input to'ladi/yashilga o'tadi.
const InputScreen = ({ screen, screenContent, onNext, onPrev, storedAnswer, onAnswer, totalScreens, factNode, figureNode }) => {
  const c = screenContent;
  const t = useT();
  const lang = useLang();
  const audio = useAudio([{ id: `s${screen}_intro`, text: c.audio.intro[lang], trigger: 'on_mount', waits_for: { type: 'check_pressed' } }]);
  const norm = (s) => String(s).replace(/[^0-9]/g, '');
  const solvedInit = storedAnswer !== undefined && norm(storedAnswer.studentAnswer) === norm(c.answer);
  const [value, setValue] = useState(storedAnswer?.studentAnswer ?? '');
  const [solved, setSolved] = useState(solvedInit);
  const [showHint, setShowHint] = useState(storedAnswer !== undefined && !solvedInit);
  const firstTryRef = useRef(storedAnswer ? (storedAnswer.firstTry ?? storedAnswer.correct ?? null) : null);
  const factVoicedRef = useRef(false);
  const factRef = useRevealScroll(solved && !!factNode, 900);
  const isCorrect = norm(value) === norm(c.answer) && norm(value) !== '';

  const submit = () => {
    if (norm(value) === '' || solved) return;
    if (firstTryRef.current === null) firstTryRef.current = isCorrect;
    audio.triggerEvent('check_pressed');
    onAnswer({ stage: SCREEN_META[screen].scope, screenIdx: screen, question: c.question[lang], options: null, correctIndex: null, correctAnswer: c.answer, studentAnswerIndex: null, studentAnswer: String(value), correct: firstTryRef.current, firstTry: firstTryRef.current });
    if (isCorrect) { setSolved(true); setShowHint(false); } else { setShowHint(true); }
    if (!audio.muted) {
      setTimeout(() => {
        const e = getAudioEngine(); if (!e || audio.muted) return;
        if (isCorrect) { e.pushOneOff(c.audio.on_correct[lang]); if (c.fact_audio && !factVoicedRef.current) { factVoicedRef.current = true; e.pushOneOff(c.fact_audio[lang]); } }
        else { e.pushOneOff(c.audio.on_wrong[lang] + ' ' + c.hint[lang]); }
      }, 300);
    }
  };

  const navContent = (<><NavBack onPrev={onPrev} label={<BackLabel/>}/><NavNext disabled={!solved} onClick={onNext} label={<NextLabel/>}/></>);
  return (
    <Stage eyebrow={c.eyebrow} screen={screen} totalScreens={totalScreens} navContent={navContent} audioState={audio}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 'clamp(14px, 2.4vw, 20px)' }}>
        <div className="fade-up">
          <p className="eyebrow" style={{ color: T.accent }}>{t(c.eyebrow)} · {t(c.label)}</p>
          {/* Kontekstda masalaning sharti (masalan 4?2) turadi — u eng och kulrangda
              qolib ketmasligi kerak, shuning uchun ink2. Savolning o'zi esa boshqa
              sarlavhalardan ajralib turishi uchun kattaroq va to'q. */}
          {c.context && <p className="small" style={{ marginTop: 6, color: T.ink2 }}>{t(c.context)}</p>}
          <h2 className="title h-sub" style={{ marginTop: 8, fontSize: 'clamp(19px, 3.1vw, 23px)', color: T.ink }}>{t(c.question)}</h2>
        </div>
        {figureNode && <div className="frame fade-up delay-1" style={{ padding: 'clamp(12px, 2.2vw, 18px)' }}>{figureNode}</div>}
        <div className="frame fade-up delay-1" style={{ display: 'flex', flexDirection: 'column', gap: 16, alignItems: 'center' }}>
          <input type="text" inputMode="numeric" className={`answer-input ${solved ? 'correct' : (showHint ? 'wrong' : '')}`} value={value} placeholder={t(c.placeholder)} onChange={e => setValue(e.target.value)} disabled={solved} onKeyDown={e => e.key === 'Enter' && submit()} style={{ width: 'min(100%, 320px)' }}/>
          <PlaceGrid answer={c.answer} filled={solved}/>
        </div>
        {!solved && (
          <div className="fade-up delay-2" style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button className="btn-white-accent" disabled={!value} onClick={submit} style={{ padding: 'clamp(10px, 1.7vw, 12px) clamp(20px, 2.5vw, 27px)', fontSize: 'clamp(12px, 1.5vw, 14px)' }}>{lang === 'uz' ? 'Tekshirish' : 'Проверить'}</button>
          </div>
        )}
        {solved && (
          <FeedbackBlock show={true} isCorrect={true}>
            <p className="small mono" style={{ margin: 0, marginBottom: 8, fontWeight: 600, color: T.success, textTransform: 'uppercase', letterSpacing: '0.08em', display: 'flex', alignItems: 'center', gap: 6 }}><span aria-hidden="true">✓</span>{lang === 'uz' ? "To'g'ri" : 'Верно'}</p>
            <p className="body" style={{ margin: 0 }}>{t(c.fb_correct)}</p>
          </FeedbackBlock>
        )}
        {solved && factNode && <div ref={factRef}>{factNode}</div>}
        {!solved && <HintBlock show={showHint}>{t(c.hint)}</HintBlock>}
      </div>
    </Stage>
  );
};

// Xato o'qishni top (s7) — keep-visible: to'g'ri (xato) variant qoladi, qolganlari yig'iladi.
const OddOneOut = ({ screen, screenContent, onNext, onPrev, storedAnswer, onAnswer, totalScreens, factNode }) => {
  const c = screenContent;
  const t = useT();
  const lang = useLang();
  const correctIdx = c.errorIdx;
  const audio = useAudio([{ id: `s${screen}_intro`, text: c.audio.intro[lang], trigger: 'on_mount', waits_for: { type: 'option_picked' } }]);
  const wasSolved = storedAnswer?.solved === true || storedAnswer?.correct === true;
  const [solved, setSolved] = useState(wasSolved);
  const [picked, setPicked] = useState(wasSolved ? correctIdx : null);
  const [wrong, setWrong] = useState(() => new Set());
  const firstTryRef = useRef(storedAnswer ? (storedAnswer.firstTry ?? storedAnswer.correct ?? null) : null);
  const advancedRef = useRef(wasSolved);
  const factRef = useRevealScroll(solved && !!factNode, 900);

  const pick = (i) => {
    if (solved || wrong.has(i)) return;
    const isC = i === correctIdx;
    if (firstTryRef.current === null) firstTryRef.current = isC;
    setPicked(i);
    if (!advancedRef.current) { advancedRef.current = true; audio.triggerEvent('option_picked'); }
    if (isC) {
      setSolved(true);
      onAnswer({ stage: SCREEN_META[screen].scope, screenIdx: screen, question: c.question[lang], options: c.items.map(it => it.num), correctIndex: correctIdx, correctAnswer: c.items[correctIdx].num, studentAnswerIndex: i, studentAnswer: c.items[i].num, correct: firstTryRef.current, firstTry: firstTryRef.current, solved: true });
    } else {
      setWrong(prev => { const n = new Set(prev); n.add(i); return n; });
    }
    if (!audio.muted) {
      setTimeout(() => {
        const e = getAudioEngine(); if (!e || audio.muted) return;
        const wv = (c[`wrong_${i}`] && c[`wrong_${i}`][lang]) || c.audio.on_wrong[lang];
        e.pushOneOff(isC ? c.audio.on_correct[lang] : wv);
      }, 300);
    }
  };

  const navContent = (<><NavBack onPrev={onPrev} label={<BackLabel/>}/><NavNext disabled={!solved} onClick={onNext} label={<NextLabel/>}/></>);
  return (
    <Stage eyebrow={c.eyebrow} screen={screen} totalScreens={totalScreens} navContent={navContent} audioState={audio}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 'clamp(12px, 2vw, 16px)' }}>
        <div className="fade-up">
          <h2 className="title h-sub">{t(c.question)}</h2>
          <p className="small" style={{ marginTop: 6, color: T.ink3 }}>{t(c.lead)}</p>
        </div>
        <div className="fade-up delay-1" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {c.items.map((it, i) => {
            const isCorrect = i === correctIdx;
            const isWrongPicked = wrong.has(i);
            const collapse = solved && !isCorrect;
            let cls = 'option';
            if (solved && isCorrect) cls += ' option-correct';
            else if (isWrongPicked) cls += ' option-picked-wrong';
            return (
              <button key={i} className={cls} disabled={solved || isWrongPicked} onClick={() => pick(i)}
                style={{ padding: collapse ? '0 clamp(14px, 2.1vw, 18px)' : 'clamp(11px, 1.7vw, 14px) clamp(14px, 2.1vw, 18px)', maxHeight: collapse ? 0 : 140, opacity: collapse ? 0 : 1, overflow: 'hidden', borderWidth: collapse ? 0 : undefined, display: 'flex', alignItems: 'center', gap: 12, transition: 'opacity 0.5s cubic-bezier(0.33,0,0.2,1), max-height 0.65s cubic-bezier(0.33,0,0.2,1), padding 0.5s cubic-bezier(0.33,0,0.2,1)', transitionDelay: collapse ? `${i * 0.06}s` : '0s' }}>
                <span className="mono small" style={{ minWidth: 20, color: solved && isCorrect ? T.success : (isWrongPicked ? T.accent : T.ink3) }}>{solved && isCorrect ? '✓' : (isWrongPicked ? '✗' : String.fromCharCode(65 + i))}</span>
                <span style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2, textAlign: 'left' }}>
                  <span className="display" style={{ fontSize: 'clamp(16px, 2.6vw, 22px)' }}>{it.num}</span>
                  <span className="small" style={{ color: T.ink2 }}>{t(it.reading)}</span>
                </span>
              </button>
            );
          })}
        </div>
        <FeedbackBlock show={picked !== null} isCorrect={solved} wrongClass="frame-tip">
          <p className="small mono" style={{ margin: 0, marginBottom: 8, fontWeight: 600, color: solved ? T.success : '#D8A93A', textTransform: 'uppercase', letterSpacing: '0.08em', display: 'flex', alignItems: 'center', gap: 6 }}><span aria-hidden="true">{solved ? '✓' : '✗'}</span>{solved ? (lang === 'uz' ? "To'g'ri" : 'Верно') : (lang === 'uz' ? 'Maslahat' : 'Подсказка')}</p>
          <p className="body" style={{ margin: 0 }}>{t(solved ? c.correct_text : (c[`wrong_${picked}`] || c.audio.on_wrong))}</p>
        </FeedbackBlock>
        {solved && factNode && <div ref={factRef}>{factNode}</div>}
      </div>
    </Stage>
  );
};

// Tasniflash (s12) — son bittalab chiqadi, bola guruhni bosadi; веди-до-верного; joylanganlar yashil chip.
const Classify = ({ screen, screenContent, onNext, onPrev, storedAnswer, onAnswer, totalScreens }) => {
  const c = screenContent;
  const t = useT();
  const lang = useLang();
  const cards = c.cards;
  const total = cards.length;
  const audio = useAudio([{ id: `s${screen}_intro`, text: c.audio.intro[lang], trigger: 'on_mount', waits_for: { type: 'option_picked' } }]);
  const wasSolved = storedAnswer?.solved === true;
  // Tartib HAR seansda RANDOM (Fisher-Yates, useState init — seans ichida o'zgarmaydi, tiklanish buzilmaydi).
  const [deck] = useState(() => shuffleArr([...Array(total).keys()]));
  const [pos, setPos] = useState(wasSolved ? total : 0);
  const [placed, setPlaced] = useState(() => (wasSolved ? cards.map(c2 => c2.bin) : []));
  const [wrongBin, setWrongBin] = useState(null);
  const firstTryRef = useRef(storedAnswer ? (storedAnswer.firstTry ?? storedAnswer.correct ?? null) : null);
  const advancedRef = useRef(wasSolved);
  const solved = pos >= total;
  const cardIdx = solved ? -1 : deck[pos];

  const tap = (bin) => {
    if (solved) return;
    const isC = bin === cards[cardIdx].bin;
    if (!advancedRef.current) { advancedRef.current = true; audio.triggerEvent('option_picked'); }
    if (isC) {
      setWrongBin(null);
      const np = [...placed]; np[cardIdx] = bin; setPlaced(np);
      const nPos = pos + 1; setPos(nPos);
      if (nPos >= total) {
        if (firstTryRef.current === null) firstTryRef.current = true;
        onAnswer({ stage: SCREEN_META[screen].scope, screenIdx: screen, question: c.title[lang], options: null, correctIndex: null, correctAnswer: 'sorted', studentAnswer: JSON.stringify(np), correct: firstTryRef.current, firstTry: firstTryRef.current, solved: true });
        if (!audio.muted) { const e = getAudioEngine(); if (e) e.pushOneOff(c.audio.on_correct[lang]); }
      }
    } else {
      if (firstTryRef.current === null || firstTryRef.current === true) firstTryRef.current = false;
      setWrongBin(bin);
      if (!audio.muted) { setTimeout(() => { const e = getAudioEngine(); if (e && !audio.muted) e.pushOneOff(c.audio.on_wrong[lang] + ' ' + c.hint[lang]); }, 300); }
    }
  };

  const bins = [{ key: 'a', label: c.bin_a }, { key: 'b', label: c.bin_b }];
  const navContent = (<><NavBack onPrev={onPrev} label={<BackLabel/>}/><NavNext disabled={!solved} onClick={onNext} label={<NextLabel/>}/></>);
  return (
    <Stage eyebrow={c.eyebrow} screen={screen} totalScreens={totalScreens} navContent={navContent} audioState={audio}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 'clamp(12px, 2vw, 16px)' }}>
        <div className="fade-up">
          <h2 className="title h-sub">{t(c.title)}</h2>
          {!solved && <p className="small" style={{ marginTop: 6, color: T.ink3 }}>{t(c.lead)}</p>}
        </div>
        {!solved && (
          <div className="frame fade-up delay-1" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, minHeight: 92, justifyContent: 'center' }}>
            <p className="small mono" style={{ margin: 0, color: T.ink3 }}>{pos + 1} / {total}</p>
            <div key={pos} className="display fade-up" style={{ fontSize: 'clamp(26px, 5.6vw, 42px)', color: T.ink }}>{cards[cardIdx].label}</div>
          </div>
        )}
        <div className="fade-up delay-2" style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 12 }}>
          {bins.map(b => {
            const chips = placed.map((p, k) => (p === b.key ? cards[k].label : null)).filter(Boolean);
            const isWrong = wrongBin === b.key;
            return (
              <button key={b.key} disabled={solved} onClick={() => tap(b.key)} className="option" style={{ display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'stretch', padding: 'clamp(12px, 2vw, 16px)', borderWidth: isWrong ? 2 : undefined, borderStyle: isWrong ? 'solid' : undefined, borderColor: isWrong ? T.accent : undefined, cursor: solved ? 'default' : 'pointer' }}>
                <span className="small mono" style={{ color: T.ink2, fontWeight: 700 }}>{t(b.label)}</span>
                <span style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {chips.map((ch, k) => (<span key={k} className="mono small" style={{ padding: '3px 8px', borderRadius: 8, background: '#E3F0E8', color: T.success }}>{ch}</span>))}
                </span>
              </button>
            );
          })}
        </div>
        {wrongBin && !solved && <HintBlock show={true}>{t(c.hint)}</HintBlock>}
        {solved && (
          <FeedbackBlock show={true} isCorrect={true}>
            <p className="small mono" style={{ margin: 0, marginBottom: 8, fontWeight: 600, color: T.success, textTransform: 'uppercase', letterSpacing: '0.08em', display: 'flex', alignItems: 'center', gap: 6 }}><span aria-hidden="true">✓</span>{lang === 'uz' ? "To'g'ri" : 'Верно'}</p>
            <p className="body" style={{ margin: 0 }}>{t(c.correct_text)}</p>
          </FeedbackBlock>
        )}
      </div>
    </Stage>
  );
};

// Moslash (s11) — songa bos, ro'yxatdan o'qilishini tanla; keep-visible (savol qoladi); веди-до-верного.
const DragMatch = ({ screen, screenContent, onAnswer, onNext, onPrev, totalScreens, factNode }) => {
  const c = screenContent;
  const t = useT();
  const lang = useLang();
  const isMobile = useIsMobile();
  const pairs = c.pairs;
  const n = pairs.length;
  const audio = useAudio([{ id: `s${screen}_intro`, text: c.audio.intro[lang], trigger: 'on_mount', waits_for: { type: 'check_pressed' } }]);
  const [order] = useState(() => shuffleArr([...Array(n).keys()]));
  const [assign, setAssign] = useState(() => Array(n).fill(null));
  const [activeSlot, setActiveSlot] = useState(null);
  const [solved, setSolved] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const firstTryRef = useRef(null);
  const factRef = useRevealScroll(solved && !!factNode, 900);
  // Slot bosilganda pastda ochiladigan variantlar ro'yxati — tap natijasi, mobilda
  // ekrandan pastda qolmasligi uchun ko'rinishga olib kelinadi.
  const optionsRef = useRevealScroll(!solved && activeSlot !== null);

  const allPlaced = assign.every(a => a !== null);
  const isCorrect = assign.every((a, k) => a === k);
  const slotOf = (pairIdx) => assign.findIndex(a => a === pairIdx);

  const assignToActive = (pairIdx) => {
    if (solved || activeSlot === null) return;
    setAssign(prev => { const nx = prev.map(a => (a === pairIdx ? null : a)); nx[activeSlot] = pairIdx; return nx; });
    setActiveSlot(null);
  };
  const clearSlot = (k, e) => { if (e) e.stopPropagation(); if (solved) return; setAssign(prev => { const nx = [...prev]; nx[k] = null; return nx; }); };

  const check = () => {
    if (solved || !allPlaced) return;
    if (firstTryRef.current === null) firstTryRef.current = isCorrect;
    audio.triggerEvent('check_pressed');
    onAnswer({ stage: SCREEN_META[screen].scope, screenIdx: screen, question: c.title[lang], options: null, correctIndex: null, correctAnswer: 'match', studentAnswer: JSON.stringify(assign), correct: firstTryRef.current, firstTry: firstTryRef.current });
    if (isCorrect) { setSolved(true); setShowHint(false); setActiveSlot(null); } else { setShowHint(true); }
    if (!audio.muted) { const txt = isCorrect ? c.audio.on_correct[lang] : (c.audio.on_wrong[lang] + ' ' + c.hint[lang]); setTimeout(() => { const e = getAudioEngine(); if (e && !audio.muted) e.pushOneOff(txt); }, 300); }
  };

  const navContent = (<><NavBack onPrev={onPrev} label={<BackLabel/>}/><NavNext disabled={!solved} onClick={onNext} label={<NextLabel/>}/></>);
  const readingFont = isMobile ? 'clamp(12px, 3.4vw, 14px)' : 'clamp(13px, 1.7vw, 15px)';
  return (
    <Stage eyebrow={c.eyebrow} screen={screen} totalScreens={totalScreens} navContent={navContent} audioState={audio}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 'clamp(12px, 2vw, 16px)' }}>
        <div className="fade-up">
          <h2 className="title h-sub">{t(c.title)}</h2>
          {!solved && <p className="small" style={{ marginTop: 6, color: T.ink3 }}>{t(c.lead)}</p>}
        </div>
        <div className="fade-up delay-1" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {pairs.map((pr, k) => {
            const placedPair = assign[k];
            const active = activeSlot === k;
            return (
              <div key={k} className="frame" onClick={() => { if (!solved) setActiveSlot(active ? null : k); }}
                style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 'clamp(10px,1.8vw,14px)', cursor: solved ? 'default' : 'pointer', border: `2px solid ${solved ? T.success : (active ? T.accent : 'transparent')}`, transition: 'border-color 0.25s ease' }}>
                <div style={{ minWidth: 'clamp(100px, 28vw, 150px)' }}>
                  <div className="display" style={{ fontSize: 'clamp(18px, 3.6vw, 26px)', color: T.ink }}>{pr.number}</div>
                  <div className="small mono" style={{ color: T.ink3 }}>{t(pr.label)}</div>
                </div>
                <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8 }}>
                  {placedPair !== null ? (
                    <>
                      <span style={{ flex: 1, fontSize: readingFont, lineHeight: 1.3, color: solved ? T.success : T.ink }}>{t(pairs[placedPair].reading)}</span>
                      {!solved && <button onClick={(e) => clearSlot(k, e)} aria-label={lang === 'uz' ? 'tozalash' : 'очистить'} className="mono" style={{ border: 'none', background: 'transparent', color: T.ink3, cursor: 'pointer', fontSize: 16, lineHeight: 1, padding: 4 }}>×</button>}
                    </>
                  ) : (
                    <span className="small" style={{ color: active ? T.accent : T.ink3 }}>{active ? (lang === 'uz' ? "ro'yxatdan tanlang ↓" : 'выбери из списка ↓') : (lang === 'uz' ? 'tanlash' : 'выбрать')}</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        {!solved && activeSlot !== null && (
          <div ref={optionsRef} className="fade-up" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {order.map(pi => {
              const usedSlot = slotOf(pi);
              const usedHere = usedSlot === activeSlot;
              return (
                <button key={pi} onClick={() => assignToActive(pi)} className="option" style={{ padding: 'clamp(10px,1.8vw,13px) clamp(12px,2vw,16px)', fontSize: readingFont, lineHeight: 1.3, textAlign: 'left', display: 'flex', alignItems: 'center', gap: 10, opacity: usedSlot >= 0 && !usedHere ? 0.5 : 1, borderColor: usedHere ? T.accent : undefined }}>
                  <span className="mono small" style={{ minWidth: 18, color: usedSlot >= 0 ? T.accent : T.ink3 }}>{usedSlot >= 0 ? (usedHere ? '✓' : '•') : ''}</span>
                  <span style={{ flex: 1 }}>{t(pairs[pi].reading)}</span>
                </button>
              );
            })}
          </div>
        )}
        {!solved && (
          <div className="fade-up delay-2" style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button className="btn-white-accent" disabled={!allPlaced} onClick={check} style={{ padding: 'clamp(10px, 1.7vw, 12px) clamp(20px, 2.5vw, 27px)', fontSize: 'clamp(12px, 1.5vw, 14px)' }}>{lang === 'uz' ? 'Tekshirish' : 'Проверить'}</button>
          </div>
        )}
        {solved && (
          <FeedbackBlock show={true} isCorrect={true}>
            <p className="small mono" style={{ margin: 0, marginBottom: 8, fontWeight: 600, color: T.success, textTransform: 'uppercase', letterSpacing: '0.08em', display: 'flex', alignItems: 'center', gap: 6 }}><span aria-hidden="true">✓</span>{lang === 'uz' ? "To'g'ri" : 'Верно'}</p>
            <p className="body" style={{ margin: 0 }}>{t(c.correct_text)}</p>
          </FeedbackBlock>
        )}
        {solved && factNode && <div ref={factRef}>{factNode}</div>}
        {!solved && <HintBlock show={showHint}>{t(c.hint)}</HintBlock>}
      </div>
    </Stage>
  );
};

// ============================================================
// ЭКРАНЫ
// Qiyinlik pog'onasi: 8/9/12 -> 12 va 13 -> 21/23/27/33 -> 20..30 -> 48 ning yoyilmasi.
// Rasmli: s0, s1, s2, s3, s4, s5, s6, s8, s9, s10.
// Rasmsiz (bo'lib tekshirish): s7, s11, s12, s13.
// ============================================================
const UNIT = { ru: 'тыс.', uz: 'ming' };
const LBL_DIVISORS = { ru: 'делителя', uz: "bo'luvchi" };

const Screen0 = ({ screen, totalScreens, onAnswer, onNext }) => {
  const c = CONTENT.s0;
  const t = useT();
  const lang = useLang();
  const audio = useAudio([{ id: 's0_intro', text: c.audio.intro[lang], trigger: 'on_mount', waits_for: { type: 'option_picked' } }]);
  const [picked, setPicked] = useState(null);
  const [showOptions, setShowOptions] = useState(false);
  const startedRef = useRef(false);
  useEffect(() => {
    if (audio.muted) { setShowOptions(true); return; }
    if (audio.isPlaying) startedRef.current = true;
    if (startedRef.current && !audio.isPlaying) setShowOptions(true);
  }, [audio.isPlaying, audio.muted]);
  useEffect(() => {
    const words = (c.audio.intro[lang] || '').trim().split(/\s+/).filter(Boolean).length;
    const ms = Math.max(4000, Math.min(Math.round(words / 2.3 * 1000) + 1500, 16000));
    const tmr = setTimeout(() => setShowOptions(true), ms);
    return () => clearTimeout(tmr);
  }, [lang]);
  const optionsRef = useRevealScroll(showOptions);
  const pick = (v) => { if (picked !== null) return; setPicked(v); onAnswer({ stage: null, screenIdx: screen, studentAnswer: v, correct: true }); audio.triggerEvent('option_picked'); setTimeout(onNext, 300); };
  return (
    <Stage eyebrow={c.eyebrow} screen={screen} totalScreens={totalScreens} audioState={audio}>
      <div style={{ position: 'relative', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 'clamp(12px, 2.2vw, 18px)' }}>
        <Floaters/>
        <p className="eyebrow fade-up" style={{ position: 'relative', color: T.accent }}>{t(c.eyebrow)}</p>
        <h1 className="title h-title fade-up" style={{ position: 'relative', margin: 0 }}>{t(c.global_q)}</h1>
        <p className="body fade-up delay-1" style={{ position: 'relative', color: T.ink2, margin: 0, maxHeight: showOptions ? 0 : 300, opacity: showOptions ? 0 : 1, marginBottom: showOptions ? 'calc(-1 * clamp(12px, 2.2vw, 18px))' : 0, overflow: 'hidden', transition: 'opacity 0.45s cubic-bezier(0.4, 0, 0.2, 1), max-height 0.6s cubic-bezier(0.4, 0, 0.2, 1), margin-bottom 0.6s cubic-bezier(0.4, 0, 0.2, 1)' }}>{t(c.lead)}</p>
        <div className="frame fade-up delay-2" style={{ position: 'relative', display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 'clamp(10px, 2.4vw, 18px)', padding: 'clamp(14px, 2.5vw, 18px)' }}>
          <PriceTag value={12} unit={t(UNIT)} size={showOptions ? 'md' : 'lg'}/>
          <PriceTag value={13} unit={t(UNIT)} size={showOptions ? 'md' : 'lg'}/>
        </div>
        <h2 className="title h-sub fade-up delay-2" style={{ position: 'relative', margin: 0 }}>{t(c.question)}</h2>
        {showOptions && (
          <div ref={optionsRef} className="fade-up" style={{ position: 'relative', display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[{ id: 'yes', label: c.opt_yes }, { id: 'no', label: c.opt_no }, { id: 'idk', label: c.opt_idk }].map(opt => (
              <button key={opt.id} className="option" disabled={picked !== null} onClick={() => pick(opt.id)} style={{ padding: 'clamp(13px, 1.9vw, 15px) clamp(16px, 2.5vw, 20px)', fontSize: 'clamp(15px, 1.9vw, 15px)' }}>{t(opt.label)}</button>
            ))}
          </div>
        )}
      </div>
    </Stage>
  );
};

// s1 — o'tgan darslardagi alomatlarni eslash.
const S1_PRICES = [8, 9, 12, 10];
const Screen1 = (props) => {
  const t = useT();
  const c = CONTENT.s1;
  const base = [t(c.opt0), t(c.opt1), t(c.opt2), t(c.opt3)];
  const { options, correctIdx, content } = shuffleMC(c, base, c.correctIndex, [3, 2, 0, 1]);
  const question = (<><p className="small" style={{ color: T.ink3, marginBottom: 8 }}>{t(c.bridge)}</p><h2 className="title h-sub">{mt(t(c.question))}</h2></>);
  const figure = (solved) => (
    <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 'clamp(6px, 1.6vw, 12px)' }}>
      {S1_PRICES.map(v => <PriceTag key={v} value={v} unit={t(UNIT)} tone={solved ? (v % 6 === 0 ? 'ok' : 'no') : 'plain'}/>)}
    </div>
  );
  return <QuestionScreen {...props} idx={props.screen} totalScreens={TOTAL_SCREENS} screenMeta={SCREEN_META[props.screen]} screenContent={content} question={question} options={options} correctIdx={correctIdx} figure={figure}/>;
};

// s2 — bo'luvchilarni sanaymiz: ko'p / roppa-rosa ikkita.
const S2_CASES = [12, 13, 18, 19];
const Screen2 = (props) => (
  <StepExploration {...props} screenContent={CONTENT.s2} totalScreens={TOTAL_SCREENS}
    renderBody={({ t, lang, step }) => {
      const v = S2_CASES[Math.min(step, S2_CASES.length - 1)];
      const two = divisorsOf(v).length === 2;
      return (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 'clamp(14px, 2.4vw, 18px)' }}>
          <h2 className="title h-title fade-up" style={{ margin: 0 }}>{t(CONTENT.s2.title)}</h2>
          <p className="body fade-up delay-1" style={{ color: T.ink2 }}>{t(CONTENT.s2.bridge)}</p>
          <div className="frame fade-up delay-2" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
            <PriceTag value={v} unit={t(UNIT)}/>
            <DivisorFan value={v} tone={two ? 'ok' : 'no'} countLabel={t(LBL_DIVISORS)} size="lg"/>
          </div>
          <StepLinesAccum lines={CONTENT.s2.audio[lang]} step={step}/>
        </div>
      );
    }}/>
);

// s3 — ta'rif: ikkita bo'luvchi / ikkitadan ko'p, yonma-yon.
const Screen3 = (props) => {
  const lang = useLang();
  const example = (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
        <span className="mono small" style={{ color: T.success, fontWeight: 700 }}>{lang === 'uz' ? 'TUB · 13' : 'ПРОСТОЕ · 13'}</span>
        <DivisorFan value={13} tone="ok"/>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
        <span className="mono small" style={{ color: T.accent, fontWeight: 700 }}>{lang === 'uz' ? 'MURAKKAB · 12' : 'СОСТАВНОЕ · 12'}</span>
        <DivisorFan value={12} tone="no"/>
      </div>
    </div>
  );
  return <RuleScreen {...props} screenContent={CONTENT.s3} totalScreens={TOTAL_SCREENS} exampleNode={example}/>;
};

// s4 — ta'rifni qo'llash. Javobdan keyin to'rttala narx yoyilmasi ochiladi.
const S4_PRICES = [21, 27, 23, 33];
const Screen4 = (props) => {
  const t = useT();
  const c = CONTENT.s4;
  const base = [t(c.opt0), t(c.opt1), t(c.opt2), t(c.opt3)];
  const { options, correctIdx, content } = shuffleMC(c, base, c.correctIndex, [0, 3, 1, 2]);
  const question = (<><p className="small" style={{ color: T.ink3, marginBottom: 8 }}>{t(c.bridge)}</p><h2 className="title h-sub">{mt(t(c.question))}</h2></>);
  const figure = (solved) => (solved
    ? <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>{S4_PRICES.map(v => <FactorChain key={v} value={v}/>)}</div>
    : <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 'clamp(6px, 1.6vw, 12px)' }}>{S4_PRICES.map(v => <PriceTag key={v} value={v} unit={t(UNIT)}/>)}</div>);
  return <QuestionScreen {...props} idx={props.screen} totalScreens={TOTAL_SCREENS} screenMeta={SCREEN_META[props.screen]} screenContent={content} question={question} options={options} correctIdx={correctIdx} figure={figure}/>;
};

// s5 — 1 soni: bitta bo'luvchi, shuning uchun alohida turadi.
const Screen5 = (props) => (
  <StepExploration {...props} screenContent={CONTENT.s5} totalScreens={TOTAL_SCREENS} factOnLast
    renderBody={({ t, lang, step, last }) => (
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 'clamp(12px, 2.2vw, 16px)' }}>
        <h2 className="title h-title fade-up" style={{ margin: 0 }}>{t(CONTENT.s5.title)}</h2>
        <p className="body fade-up delay-1" style={{ color: T.ink2 }}>{t(CONTENT.s5.bridge)}</p>
        <div className="frame fade-up delay-2" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
          <DivisorFan value={1} tone="no" countLabel={t(LBL_DIVISORS)} size="lg"/>
          {step >= 2 && (
            <span className="dv-chip fade-up" style={{ background: '#FFE8E1', color: T.accent, borderColor: T.accent }}>
              {lang === 'uz' ? 'na tub, na murakkab' : 'ни простое, ни составное'}
            </span>
          )}
        </div>
        <StepLinesAccum lines={CONTENT.s5.audio[lang]} step={step}/>
        {step >= last && <FactCard badge={FB_HIST} anim={<AnimStars/>} text={CONTENT.s5.fact}/>}
      </div>
    )}/>
);

const Screen6 = (props) => (<RuleScreen {...props} screenContent={CONTENT.s6} totalScreens={TOTAL_SCREENS} exampleNode={<DivisorChips list={['2', '3', '5', '7']}/>}/>);

const Screen7 = (props) => <OddOneOut {...props} screenContent={CONTENT.s7} totalScreens={TOTAL_SCREENS}/>;

// s8 — Eratosfen g'alviri, KO'RSATUV: har qadamda ortiqchasi o'chib boradi.
const Screen8 = (props) => (
  <StepExploration {...props} screenContent={CONTENT.s8} totalScreens={TOTAL_SCREENS}
    renderBody={({ t, lang, step }) => (
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 'clamp(10px, 2vw, 14px)' }}>
        <h2 className="title h-title fade-up" style={{ margin: 0 }}>{t(CONTENT.s8.title)}</h2>
        <p className="small fade-up delay-1" style={{ color: T.ink2, margin: 0 }}>{t(CONTENT.s8.bridge)}</p>
        <div className="frame fade-up delay-2" style={{ padding: 'clamp(10px, 2vw, 14px)' }}>
          <SieveGrid max={50} step={step}/>
        </div>
        <StepLinesAccum lines={CONTENT.s8.audio[lang]} step={step}/>
      </div>
    )}/>
);

const Screen9 = (props) => {
  const fig = <DivisorChips list={['20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30']}/>;
  return <InputScreen {...props} screenContent={CONTENT.s9} totalScreens={TOTAL_SCREENS} figureNode={fig} factNode={<FactCard badge={FB_SCI} anim={<AnimDigits/>} text={CONTENT.s9.fact}/>}/>;
};

// s10 — tub ko'paytuvchilarga yoyish (Dars05 uchun ko'prik).
const S10_STEPS = [6, 3, 12];
const Screen10 = (props) => (
  <StepExploration {...props} screenContent={CONTENT.s10} totalScreens={TOTAL_SCREENS}
    renderBody={({ t, lang, step }) => (
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 'clamp(12px, 2.2vw, 16px)' }}>
        <h2 className="title h-title fade-up" style={{ margin: 0 }}>{t(CONTENT.s10.title)}</h2>
        <p className="body fade-up delay-1" style={{ color: T.ink2 }}>{t(CONTENT.s10.bridge)}</p>
        <div className="frame fade-up delay-2" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
          <p className="mono small" style={{ margin: 0, color: T.ink3 }}>
            {step === 0 ? '12 : 2 = 6' : (step === 1 ? '6 : 2 = 3' : '')}
          </p>
          {step >= 2
            ? <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'center', gap: 'clamp(14px, 3.2vw, 30px)' }}>
                <FactorChain value={12}/>
                {step >= 3 && (
                  <div className="fade-up" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, paddingLeft: 'clamp(14px, 3.2vw, 26px)', borderLeft: '1px dashed rgba(58, 53, 48, 0.18)' }}>
                    <span className="mono small" style={{ color: T.ink3, fontWeight: 700, letterSpacing: '0.12em' }}>{lang === 'uz' ? 'USTUN USULI' : 'СТОЛБИКОМ'}</span>
                    <FactorLadder value={12}/>
                  </div>
                )}
              </div>
            : <span className="mono" style={{ fontSize: 'clamp(22px, 5vw, 34px)', fontWeight: 700, color: T.ink }}>{S10_STEPS[Math.min(step, 1)]}</span>}
        </div>
        <StepLinesAccum lines={CONTENT.s10.audio[lang]} step={step}/>
      </div>
    )}/>
);

const Screen11 = (props) => <DragMatch {...props} screenContent={CONTENT.s11} totalScreens={TOTAL_SCREENS}/>;

const Screen12 = (props) => <Classify {...props} screenContent={CONTENT.s12} totalScreens={TOTAL_SCREENS}/>;

const Screen13 = (props) => <InputScreen {...props} screenContent={CONTENT.s13} totalScreens={TOTAL_SCREENS} factNode={<FactCard badge={FB_SCI} anim={<AnimData/>} text={CONTENT.s13.fact}/>}/>;
const Screen14 = ({ screen, totalScreens, answers, onReset, onPrev, finishLesson }) => {
  const c = CONTENT.s14;
  const t = useT();
  const lang = useLang();
  const lines = c.audio[lang];
  const audio = useAudio([{ id: 's14_a0', text: lines[0], trigger: 'on_mount', waits_for: null }]);
  const voicedRef = useRef(false);
  useEffect(() => {
    if (!audio.muted && !voicedRef.current) { voicedRef.current = true; const e = getAudioEngine(); if (e) lines.slice(1).forEach(l => e.pushOneOff(l)); }
    /* eslint-disable-next-line */
  }, []);
  const scoredIdx = SCREEN_META.map((m, i) => (m.scored ? i : -1)).filter(i => i >= 0);
  const correct = scoredIdx.filter(i => answers[i]?.correct).length;
  const total = scoredIdx.length;
  const mains = [c.main_1, c.main_2, c.main_3];
  const navContent = (<><NavBack onPrev={onPrev} label={<BackLabel/>}/><button className="btn-ghost" onClick={onReset} style={{ padding: 'clamp(10px, 1.7vw, 12px) clamp(15px, 2.1vw, 20px)', fontSize: 'clamp(12px, 1.5vw, 14px)', marginLeft: 'auto' }}>{lang === 'uz' ? "Qaytadan o'tish" : 'Пройти заново'}</button><button className="btn" onClick={finishLesson} style={{ padding: 'clamp(10px, 1.7vw, 12px) clamp(18px, 2.6vw, 26px)', fontSize: 'clamp(12px, 1.5vw, 14px)' }}>{lang === 'uz' ? 'Darsni tugatish' : 'Завершить урок'}</button></>);
  return (
    <Stage eyebrow={c.eyebrow} screen={screen} totalScreens={totalScreens} navContent={navContent} audioState={audio}>
      <div style={{ position: 'relative', flex: 1, display: 'flex', flexDirection: 'column', gap: 'clamp(14px, 2.4vw, 18px)', justifyContent: 'center' }}>
        <Floaters/>
        <div className="fade-up" style={{ position: 'relative' }}>
          <p className="eyebrow" style={{ color: T.success }}>{t(c.eyebrow)}</p>
          <h2 className="title h-title" style={{ marginTop: 8 }}>{t(c.heading)}</h2>
        </div>
        <div className="frame-success fade-up delay-1" style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 14 }}>
          <span className="mono" style={{ fontSize: 'clamp(24px, 5.5vw, 32px)', fontWeight: 700, color: T.success, lineHeight: 1, flexShrink: 0 }}>{correct} / {total}</span>
          <span className="body" style={{ margin: 0, color: T.ink2 }}>{t(c.score_label)}</span>
        </div>
        <div className="frame fade-up delay-1" style={{ position: 'relative' }}>
          <p className="eyebrow" style={{ color: T.ink2, marginBottom: 14 }}>{t(c.main_label)}</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {mains.map((m, i) => (<div key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}><span className="mono small" style={{ color: T.accent, marginTop: 2 }}>{String(i + 1).padStart(2, '0')}</span><p className="body" style={{ margin: 0 }}>{t(m)}</p></div>))}
          </div>
        </div>
        <div className="frame-success fade-up delay-2" style={{ position: 'relative' }}>
          <p className="body" style={{ margin: 0 }}>{t(c.hook_close)}</p>
        </div>
        <ConnectionsBlock c={c}/>
      </div>
    </Stage>
  );
};

// ============================================================
const STYLES = `
html, body { margin: 0; padding: 0; }
.lesson-root, .lesson-root * { box-sizing: border-box; }
/* position: fixed + inset: 0 — dars oqimdan chiqib, doim aynan KO'RINADIGAN
   viewport'ga mixlanadi. Host (LessonPage/LMS) 100vh bilan balandroq bo'lsa ham
   body-skroll darsga ta'sir qilmaydi, "Davom" tugmasi joyidan siljimaydi.
   URL-panel ochilib-yopilganda balandlikni brauzer o'zi kuzatadi (JS o'lchovsiz). */
.lesson-root {
  font-family: 'Manrope', system-ui, sans-serif;
  color: #0E0E10;
  background: #F6F4EF;
  position: fixed;
  inset: 0;
  overflow: hidden;
  overscroll-behavior: none;
  -webkit-font-smoothing: antialiased;
  font-feature-settings: "ss01","cv11";
  zoom: var(--g1z, 1);
}
/* Mobil yagona masshtab (useMobileZoom): layout doim 390px, zoom real ekranga
   moslaydi — barcha telefonlarda aynan bir xil ko'rinish. Desktop tegilmaydi. */
@media (max-width: 639.98px) {
  .lesson-root { width: 390px; }
}

.lesson-root h1, .lesson-root h2, .lesson-root h3, .lesson-root h4, .lesson-root h5, .lesson-root h6,
.lesson-root p, .lesson-root ul, .lesson-root ol { margin: 0; padding: 0; }

.title { font-family: 'Source Serif 4', serif; font-weight: 600; line-height: 1.1; letter-spacing: -0.005em; font-variation-settings: "opsz" 60; }
.display { font-family: 'Source Serif 4', serif; font-weight: 600; line-height: 1.0; letter-spacing: -0.01em; font-variation-settings: "opsz" 60; }
.italic { font-family: 'Source Serif 4', serif; font-style: italic; font-weight: 500; font-variation-settings: "opsz" 60; }
.mono { font-family: 'JetBrains Mono', monospace; }
.mop { font-family: 'Manrope', sans-serif; font-weight: 600; color: #0E0E10; display: inline-block; padding: 0 0.06em; }

.frac { display: inline-flex; flex-direction: column; align-items: center; vertical-align: middle; line-height: 1; margin: 0 0.08em; font-family: 'Fraunces', serif; font-variation-settings: "opsz" 144; font-weight: 400; }
.frac .n, .frac .d { padding: 0 0.12em; }
.frac .bar { height: 0.08em; background: currentColor; width: 100%; margin: 0.08em 0; border-radius: 2px; }

@keyframes fade-in-up { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
.fade-up { animation: fade-in-up 0.4s ease-out forwards; opacity: 0; }
.delay-1 { animation-delay: 0.12s; } .delay-2 { animation-delay: 0.24s; }
.delay-3 { animation-delay: 0.36s; } .delay-4 { animation-delay: 0.48s; }

.feedback-block { max-height: 0; opacity: 0; overflow: hidden; transition: max-height 0.4s ease-out, opacity 0.3s ease-out 0.1s, margin-top 0.4s ease-out; margin-top: 0; }
.feedback-block.visible { max-height: 800px; opacity: 1; margin-top: clamp(14px, 2vw, 20px); }

.btn { font-family: 'Manrope', sans-serif; font-weight: 600; cursor: pointer; transition: all 0.2s; background: #0E0E10; color: #F6F4EF; letter-spacing: 0.01em; border-radius: 12px; border: none; box-shadow: 0 6px 18px -4px rgba(58, 53, 48, 0.32); }
.btn:hover:not(:disabled) { background: #FF4F28; box-shadow: 0 10px 24px -4px rgba(255, 79, 40, 0.45); }
.btn:disabled { opacity: 0.4; cursor: not-allowed; box-shadow: none; }

.btn-white-accent { font-family: 'Manrope', sans-serif; font-weight: 600; cursor: pointer; transition: all 0.2s; background: #FFFFFF; color: #FF4F28; letter-spacing: 0.01em; border-radius: 12px; border: none; box-shadow: 0 8px 22px -4px rgba(255, 79, 40, 0.35), 0 0 0 1px rgba(255, 79, 40, 0.12); }
.btn-white-accent:hover:not(:disabled) { background: #FF4F28; color: #FFFFFF; box-shadow: 0 12px 28px -6px rgba(255, 79, 40, 0.55); }
.btn-white-accent:disabled { opacity: 0.45; cursor: not-allowed; box-shadow: 0 4px 12px -4px rgba(58, 53, 48, 0.14); }

.btn-ghost { font-family: 'Manrope', sans-serif; font-weight: 600; cursor: pointer; transition: all 0.2s; background: transparent; color: #0E0E10; letter-spacing: 0.01em; border-radius: 12px; border: none; box-shadow: none; }
.btn-ghost:hover:not(:disabled) { background: #FFFFFF; box-shadow: 0 6px 18px -6px rgba(58, 53, 48, 0.18); }
.btn-ghost:disabled { opacity: 0.4; cursor: not-allowed; }

.option { background: #FFFFFF; cursor: pointer; transition: all 0.2s; font-family: 'Manrope', sans-serif; font-weight: 500; text-align: left; border-radius: 12px; width: 100%; border: none; color: #0E0E10; box-shadow: 0 6px 16px -6px rgba(58, 53, 48, 0.14); }
.option:hover:not(:disabled) { background: #FDFBF7; box-shadow: 0 10px 22px -6px rgba(58, 53, 48, 0.22); }
.option:disabled { cursor: default; }
.option-correct { background: #E3F0E8 !important; color: #1F7A4D !important; box-shadow: 0 8px 22px -6px rgba(31, 122, 77, 0.32) !important; }
.option-wrong { background: #FFFFFF !important; color: #A7A6A2 !important; opacity: 0.55 !important; box-shadow: 0 4px 12px -6px rgba(58, 53, 48, 0.08) !important; }
.option-picked-wrong { background: #FFE8E1 !important; color: #FF4F28 !important; box-shadow: 0 8px 22px -6px rgba(255, 79, 40, 0.38) !important; }

.h-title { font-size: clamp(22px, 4vw, 38px); }
.h-sub { font-size: clamp(19px, 2.7vw, 22px); }
.body { font-size: clamp(17px, 2.1vw, 17px); line-height: 1.55; }
.eyebrow { font-size: clamp(11px, 1.3vw, 11px); letter-spacing: 0.18em; text-transform: uppercase; font-weight: 600; }
.small { font-size: clamp(15px, 1.7vw, 15px); }
.frac-display { font-size: clamp(45px, 9vw, 75px); }
.frac-mid { font-size: clamp(26px, 5vw, 38px); }
.frac-sm { font-size: clamp(16px, 2.5vw, 20px); }

.stage { max-width: 936px; margin: 0 auto; height: 100%; display: flex; flex-direction: column; }
.stage-header { flex-shrink: 0; background: #F6F4EF; padding-top: clamp(12px, 2vw, 18px); padding-bottom: clamp(8px, 1.5vw, 12px); }
.stage-content { flex: 1; padding-top: clamp(10px, 1.7vw, 16px); padding-bottom: clamp(17px, 3.4vw, 34px); display: flex; flex-direction: column; overflow-y: auto; overflow-x: hidden; overscroll-behavior: contain; -webkit-overflow-scrolling: touch; }
.stage-nav { flex-shrink: 0; background: #F6F4EF; border-top: 1px solid rgba(167, 166, 162, 0.25); padding-top: clamp(12px, 2vw, 15px); padding-bottom: clamp(12px, 2vw, 15px); display: flex; gap: 12px; }

.chrome { display: flex; align-items: center; justify-content: space-between; margin-bottom: 0; }
.chrome-left { display: flex; align-items: center; gap: 10px; color: #5A5A60; }
.dot { width: 7px; height: 7px; border-radius: 50%; background: #FF4F28; box-shadow: 0 0 8px rgba(255, 79, 40, 0.55); }

.progress-track { height: 6px; background: rgba(167, 166, 162, 0.25); width: 100%; margin-bottom: 12px; border-radius: 99px; overflow: visible; }
.progress-bar { height: 100%; background: #FF4F28; transition: width 0.5s cubic-bezier(0.4, 0, 0.2, 1); border-radius: 99px; box-shadow: 0 0 10px rgba(255, 79, 40, 0.55), 0 0 3px rgba(255, 79, 40, 0.40); }

.track-wrap { position: relative; height: 26px; margin: 18px 0; display: flex; align-items: center; }
.track-bg { position: absolute; left: 0; right: 0; top: 50%; transform: translateY(-50%); height: 4px; background: rgba(167, 166, 162, 0.30); border-radius: 99px; pointer-events: none; }
.track-fill { position: absolute; left: 0; top: 50%; transform: translateY(-50%); height: 4px; background: #FF4F28; border-radius: 99px; pointer-events: none; box-shadow: 0 0 8px rgba(255, 79, 40, 0.50), 0 0 2px rgba(255, 79, 40, 0.40); transition: width 0.15s ease-out; }
.slider-input { -webkit-appearance: none; appearance: none; position: relative; width: 100%; height: 24px; background: transparent; outline: none; margin: 0; cursor: grab; z-index: 2; }
.slider-input::-webkit-slider-thumb { -webkit-appearance: none; appearance: none; width: 24px; height: 24px; background: #FF4F28; border-radius: 50%; cursor: grab; transition: transform 0.1s; border: none; box-shadow: 0 0 0 4px #F6F4EF, 0 0 12px 0 rgba(255, 79, 40, 0.55); }
.slider-input::-moz-range-thumb { width: 24px; height: 24px; background: #FF4F28; border-radius: 50%; cursor: grab; border: none; box-shadow: 0 0 0 4px #F6F4EF, 0 0 12px 0 rgba(255, 79, 40, 0.55); }
.slider-input::-webkit-slider-thumb:active { cursor: grabbing; transform: scale(1.12); }
.slider-input:disabled { cursor: not-allowed; }
.slider-input:disabled::-webkit-slider-thumb { opacity: 0.5; cursor: not-allowed; }

.answer-input { font-family: 'Fraunces', serif; font-size: clamp(22px, 4vw, 27px); font-weight: 400; text-align: center; border-radius: 12px; background: #FFFFFF; padding: 8px 12px; outline: none; border: none; color: #0E0E10; transition: all 0.2s; box-shadow: 0 6px 16px -6px rgba(58, 53, 48, 0.14); }
.answer-input:focus { box-shadow: 0 10px 22px -6px rgba(255, 79, 40, 0.30), 0 0 0 1px rgba(255, 79, 40, 0.20); }
.answer-input.correct { background: #E3F0E8; color: #1F7A4D; box-shadow: 0 8px 20px -6px rgba(31, 122, 77, 0.30); }
.answer-input.wrong { background: #FFE8E1; color: #FF4F28; box-shadow: 0 8px 20px -6px rgba(255, 79, 40, 0.36); }

.frame { background: #FFFFFF; border-radius: 16px; padding: clamp(17px, 3.4vw, 30px); border: none; box-shadow: 0 8px 22px -6px rgba(58, 53, 48, 0.14); }
.frame-soft { background: #FFE8E1; border-left: 4px solid #FF4F28; border-radius: 12px; padding: clamp(14px, 2.5vw, 20px); box-shadow: 0 6px 16px -6px rgba(255, 79, 40, 0.22); }
.frame-success { background: #E3F0E8; border-left: 4px solid #1F7A4D; border-radius: 12px; padding: clamp(14px, 2.5vw, 20px); box-shadow: 0 6px 16px -6px rgba(31, 122, 77, 0.22); }
.frame-tip { background: #FBF3D6; border-left: 4px solid #D8A93A; border-radius: 12px; padding: clamp(14px, 2.5vw, 20px); box-shadow: 0 6px 16px -6px rgba(180, 138, 30, 0.22); }

/* ===== УРОК-СПЕЦИФИЧНЫЙ CSS (div_6_04) ===== */
.place-cell { font-family: 'JetBrains Mono', monospace; display: flex; align-items: center; justify-content: center; min-width: clamp(20px, 3.6vw, 30px); height: clamp(28px, 5vw, 40px); border-radius: 8px; background: #FFFFFF; color: #A7A6A2; box-shadow: 0 4px 12px -6px rgba(58,53,48,0.16); transition: all 0.35s; }
.place-cell.filled { background: #E3F0E8; color: #1F7A4D; box-shadow: 0 6px 16px -6px rgba(31,122,77,0.30); }

@keyframes rg-dot-in { from { opacity: 0; transform: translateY(6px) scale(0.6); } to { opacity: 1; transform: none; } }

/* PriceTag — do'kon narx yorlig'i. */
.pr-tag { display: inline-flex; flex-direction: column; align-items: center; gap: 2px; padding: clamp(7px,1.5vw,11px) clamp(11px,2.2vw,16px); border-radius: 12px; border: 1.5px solid; animation: rg-dot-in 0.36s ease-out both; box-shadow: 0 5px 14px -8px rgba(58,53,48,0.35); transition: background 0.35s ease, color 0.35s ease, border-color 0.35s ease; }

/* DivisorFan — darsning yuragi: barcha bo'luvchilar chip bo'lib yoyiladi. */
.df-chip { display: inline-flex; align-items: center; justify-content: center; min-width: 1.5em; padding: 4px 8px; border-radius: 8px; background: #FFFFFF; color: #0E0E10; border: 1.5px solid rgba(167,166,162,0.4); font-weight: 700; line-height: 1.15; animation: rg-dot-in 0.32s ease-out both; }
.df-count { display: inline-flex; align-items: center; justify-content: center; padding: 4px 12px; border-radius: 99px; border: 2px solid; font-weight: 700; font-size: clamp(12px,2.3vw,15px); transition: background 0.35s ease, color 0.35s ease, border-color 0.35s ease; }

/* SieveGrid — Eratosfen g'alviri: 50 katak, o'nlab qatorlarda. */
.sv-grid { display: grid; grid-template-columns: repeat(10, 1fr); gap: clamp(2px, 0.7vw, 4px); }
.sv-cell { display: flex; align-items: center; justify-content: center; aspect-ratio: 1; border-radius: 6px; font-size: clamp(9px, 2vw, 13px); font-weight: 600; transition: background 0.4s ease, color 0.4s ease, opacity 0.4s ease; }
.sv-plain { background: #FFFFFF; color: #0E0E10; box-shadow: 0 2px 6px -3px rgba(58,53,48,0.25); }
.sv-crossed { background: transparent; color: #A7A6A2; opacity: 0.45; text-decoration: line-through; }
.sv-prime { background: #E3F0E8; color: #1F7A4D; box-shadow: 0 2px 8px -3px rgba(31,122,77,0.4); }

/* FactorChain — tub ko'paytuvchilar zanjiri (12 = 2 · 2 · 3). */
.fc-chip { display: inline-flex; align-items: center; justify-content: center; min-width: 1.5em; padding: 5px 9px; border-radius: 8px; background: #E3F0E8; color: #1F7A4D; border: 1.5px solid #1F7A4D; font-weight: 700; font-size: clamp(14px, 2.8vw, 19px); line-height: 1.15; animation: rg-dot-in 0.34s ease-out both; }

/* FactorLadder — tub ko'paytuvchilarга ustun (столбик) usuli. Qatorlar ketma-ket tushadi. */
.ladder { display: inline-grid; grid-auto-rows: auto; gap: 3px; margin: 2px 0; }
.ladder-row { display: grid; grid-template-columns: minmax(2em, 1fr) auto minmax(2em, 1fr); align-items: stretch; column-gap: clamp(12px, 2.4vw, 20px); animation: ladderIn 0.42s cubic-bezier(0.33, 0, 0.2, 1) both; }
.ladder-n { text-align: right; align-self: center; font-weight: 700; font-size: clamp(16px, 3vw, 22px); color: #0E0E10; }
.ladder-p { text-align: left; align-self: center; font-weight: 700; font-size: clamp(16px, 3vw, 22px); color: #1F7A4D; }
.ladder-bar { width: 2.5px; min-height: 1.5em; background: rgba(58, 53, 48, 0.28); border-radius: 2px; }
.ladder-one { color: #A7A6A2; }
@keyframes ladderIn { from { opacity: 0; transform: translateX(-10px); } to { opacity: 1; transform: none; } }

/* DivisorChips — ruxsat etilgan oxirgi raqamlar / alomat chiplari. */
.dv-chip { font-family: 'JetBrains Mono', monospace; font-size: clamp(13px, 2.4vw, 17px); font-weight: 600; padding: clamp(6px,1.2vw,9px) clamp(11px,2vw,15px); border-radius: 10px; border: 1.5px solid; animation: rg-dot-in 0.4s ease-out both; transition: background 0.35s ease, color 0.35s ease, border-color 0.35s ease; }

.fact-card { display: flex; gap: clamp(12px, 2.5vw, 18px); align-items: center; background: #EAF6FB; border-left: 4px solid #019ACB; border-radius: 12px; padding: clamp(12px, 2.2vw, 16px); box-shadow: 0 6px 16px -6px rgba(1, 154, 203, 0.22); }
.fact-anim { flex-shrink: 0; width: clamp(90px, 18vw, 130px); height: clamp(70px, 14vw, 96px); display: flex; align-items: center; justify-content: center; overflow: hidden; }
.fact-body { flex: 1; }
.fact-badge { display: flex; align-items: center; gap: 8px; margin: 0 0 4px; font-family: 'JetBrains Mono', monospace; font-size: clamp(10px, 1.2vw, 11px); font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; color: #019ACB; }
.fact-dot { width: 7px; height: 7px; border-radius: 50%; background: #019ACB; box-shadow: 0 0 8px rgba(1, 154, 203, 0.55); }
.fact-text { margin: 0; font-size: clamp(12px, 1.5vw, 13px); line-height: 1.4; color: #0E0E10; }
.fa-dg { display: flex; gap: 7px; align-items: center; }
.fa-dg-grp { display: flex; gap: 2px; animation: faDg 2.4s ease-in-out infinite; }
.fa-dg-grp i { width: 7px; height: clamp(20px, 4vw, 30px); background: #019ACB; opacity: 0.25; border-radius: 2px; }
.fa-dg-grp:nth-child(1) { animation-delay: 0s; }
.fa-dg-grp:nth-child(2) { animation-delay: 0.3s; }
.fa-dg-grp:nth-child(3) { animation-delay: 0.6s; }
@keyframes faDg { 0%, 100% { opacity: 0.3; } 45% { opacity: 1; } }
.fa-st { display: grid; grid-template-columns: repeat(3, 1fr); gap: clamp(6px, 1.4vw, 10px); width: clamp(70px, 14vw, 96px); }
.fa-st span { width: clamp(8px, 1.8vw, 11px); height: clamp(8px, 1.8vw, 11px); border-radius: 50%; background: #019ACB; box-shadow: 0 0 6px rgba(1, 154, 203, 0.6); animation: faSt 2.2s ease-in-out infinite; }
@keyframes faSt { 0%, 100% { opacity: 0.2; transform: scale(0.7); } 50% { opacity: 1; transform: scale(1); } }
.fa-da { display: flex; align-items: flex-end; gap: 5px; height: clamp(56px, 12vw, 80px); }
.fa-da span { width: clamp(10px, 2.2vw, 14px); background: #019ACB; opacity: 0.3; border-radius: 3px; animation: faDa 2.4s ease-in-out infinite; }
@keyframes faDa { 0%, 100% { opacity: 0.25; } 50% { opacity: 0.95; } }

.amb { position: absolute; inset: 0; overflow: hidden; pointer-events: none; z-index: 0; }
.amb-o { position: absolute; border-radius: 50%; opacity: 0.7; animation: ambFloat 15s ease-in-out infinite; background: radial-gradient(circle at 30% 30%, rgba(255, 79, 40, 0.10), rgba(255, 79, 40, 0.02)); }
.amb-o1 { width: 90px; height: 90px; left: 5%; top: 10%; animation-delay: 0s; }
.amb-o2 { width: 130px; height: 130px; right: 3%; bottom: 6%; animation-delay: -5s; background: radial-gradient(circle at 30% 30%, rgba(1, 154, 203, 0.10), rgba(1, 154, 203, 0.02)); }
.amb-o3 { width: 58px; height: 58px; left: 42%; top: 62%; animation-delay: -9s; }
@keyframes ambFloat { 0%, 100% { transform: translateY(0) translateX(0); } 33% { transform: translateY(-14px) translateX(8px); } 66% { transform: translateY(8px) translateX(-10px); } }

@media (prefers-reduced-motion: reduce) {
  .lesson-root, .lesson-root *, .lesson-root *::before, .lesson-root *::after { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; transition-duration: 0.01ms !important; scroll-behavior: auto !important; }
}
`;

// ============================================================
// КОРНЕВОЙ КОМПОНЕНТ — default export (platform_contract §1)
// ============================================================
export default function PrimeCompositeLesson({
  studentName, lang: langProp, ttsApiBase, voiceGender,
  correctSoundUrl, wrongSoundUrl, aiGradingEndpoint, onFinished,
}) {
  useMobileZoom();
  const lang = langProp || 'ru';
  const safeName = studentName || (lang === 'uz' ? "O'quvchi" : 'Ученик');
  configureLesson({ ttsApiBase: ttsApiBase || '', correctSoundUrl: correctSoundUrl || '', wrongSoundUrl: wrongSoundUrl || '', aiGradingEndpoint: aiGradingEndpoint || '', studentName: safeName, voiceGender: voiceGender || 'm' });
  const safeOnFinished = onFinished || ((payload) => { console.log('[Preview] onFinished payload:', payload); });

  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState([]);
  const startTimeRef = useRef(Date.now());

  const recordAnswer = useCallback((screenIdx, data) => {
    setAnswers(prev => { const nextArr = [...prev]; nextArr[screenIdx] = data; return nextArr; });
  }, []);

  const reset = useCallback(() => { setAnswers([]); setCurrent(0); startTimeRef.current = Date.now(); }, []);

  const finishLesson = useCallback(() => {
    const checked = answers.filter(a => a && typeof a.firstTry === 'boolean');
    const payload = {
      lessonId: LESSON_META.lessonId,
      lessonTitle: LESSON_META.lessonTitle,
      durationSec: Math.floor((Date.now() - startTimeRef.current) / 1000),
      totalQuestions: null, correctAnswers: null, scorePercent: null,
      finalScore: null, finalTotal: null, passed: null,
      firstTryStats: { total: checked.length, firstTryCorrect: checked.filter(a => a.firstTry === true).length },
      answers: answers.filter(Boolean)
    };
    safeOnFinished(payload);
  }, [answers, safeOnFinished]);

  const screens = [Screen0, Screen1, Screen2, Screen3, Screen4, Screen5, Screen6, Screen7, Screen8, Screen9, Screen10, Screen11, Screen12, Screen13, Screen14];
  const CurrentScreen = screens[current];

  const next = () => setCurrent(s => Math.min(s + 1, TOTAL_SCREENS - 1));
  const prev = () => setCurrent(s => Math.max(s - 1, 0));
  const handleAnswer = useCallback((data) => { recordAnswer(current, data); }, [current, recordAnswer]);

  return (
    <LangContext.Provider value={lang}>
      <style>{STYLES}</style>
      <div className="lesson-root">
        <CurrentScreen
          screen={current}
          studentName={safeName}
          totalScreens={TOTAL_SCREENS}
          storedAnswer={answers[current]}
          answers={answers}
          onAnswer={handleAnswer}
          onNext={next}
          onPrev={prev}
          onReset={reset}
          finishLesson={finishLesson}
        />
      </div>
    </LangContext.Provider>
  );
}
